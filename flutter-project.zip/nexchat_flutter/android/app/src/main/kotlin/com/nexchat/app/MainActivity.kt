package com.nexchat.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
