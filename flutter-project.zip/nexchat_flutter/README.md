# NexChat — Flutter Realtime Chat

Backend: **https://backend-nextchat.up.railway.app**
