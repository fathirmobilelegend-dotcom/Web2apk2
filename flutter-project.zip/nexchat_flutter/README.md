# NexChat — Flutter Realtime Chat

Backend: **http://LightSecret.duckdns.top:2001**
