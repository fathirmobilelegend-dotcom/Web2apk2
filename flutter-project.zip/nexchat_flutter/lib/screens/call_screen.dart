import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../services/call_service.dart';
import '../widgets/avatar.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final _localRenderer = RTCVideoRenderer();
  final _remoteRenderer = RTCVideoRenderer();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
    CallService.instance.state.addListener(_onState);
  }

  @override
  void dispose() {
    CallService.instance.state.removeListener(_onState);
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    await _localRenderer.initialize();
    await _remoteRenderer.initialize();
    _attach();
    setState(() => _ready = true);
  }

  void _attach() {
    final local = CallService.instance.localStream;
    final remote = CallService.instance.remoteStream;
    if (local != null) _localRenderer.srcObject = local;
    if (remote != null) _remoteRenderer.srcObject = remote;
  }

  void _onState() {
    _attach();
    if (CallService.instance.state.value == CallState.idle) {
      if (mounted) Navigator.of(context).maybePop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<CallState>(
      valueListenable: CallService.instance.state,
      builder: (_, state, __) {
        if (state == CallState.idle) return const SizedBox.shrink();
        final isVideo = CallService.instance.callType.value == 'video';
        final isActive = state == CallState.active;
        return Scaffold(
          backgroundColor: const Color(0xFF0B141A),
          body: SafeArea(child: Stack(children: [
            if (isVideo && isActive && _ready)
              Positioned.fill(child: RTCVideoView(_remoteRenderer,
                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)),
            if (isVideo && isActive && _ready)
              Positioned(top: 16, right: 16,
                child: ClipRRect(borderRadius: BorderRadius.circular(12),
                  child: SizedBox(width: 110, height: 160,
                    child: RTCVideoView(_localRenderer, mirror: true,
                      objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)))),
            if (!isVideo || !isActive)
              Center(child: ValueListenableBuilder<String>(
                valueListenable: CallService.instance.peerName,
                builder: (_, name, __) => ValueListenableBuilder<String?>(
                  valueListenable: CallService.instance.peerAvatar,
                  builder: (_, avatar, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                    AppAvatar(name: name, url: avatar, size: 130),
                    const SizedBox(height: 24),
                    Text(name, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 10),
                    Text(_statusText(state), style: const TextStyle(color: Colors.white70, fontSize: 15)),
                    if (isActive) Padding(padding: const EdgeInsets.only(top: 8),
                      child: ValueListenableBuilder<Duration>(
                        valueListenable: CallService.instance.duration,
                        builder: (_, d, __) => Text(
                          '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}',
                          style: const TextStyle(color: Colors.white, fontSize: 16)))),
                  ])))),
            Positioned(left: 0, right: 0, bottom: 34,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                if (isActive) ...[
                  ValueListenableBuilder<bool>(
                    valueListenable: CallService.instance.muted,
                    builder: (_, m, __) => _roundBtn(
                      icon: m ? Icons.mic_off : Icons.mic,
                      bg: m ? Colors.white : Colors.white24,
                      fg: m ? Colors.black : Colors.white,
                      onTap: () => CallService.instance.toggleMute())),
                  const SizedBox(width: 18),
                ],
                _roundBtn(icon: Icons.call_end, bg: Colors.red, fg: Colors.white,
                  onTap: () => CallService.instance.endCall()),
                if (isVideo && isActive) ...[
                  const SizedBox(width: 18),
                  ValueListenableBuilder<bool>(
                    valueListenable: CallService.instance.videoOff,
                    builder: (_, v, __) => _roundBtn(
                      icon: v ? Icons.videocam_off : Icons.videocam,
                      bg: v ? Colors.white : Colors.white24,
                      fg: v ? Colors.black : Colors.white,
                      onTap: () => CallService.instance.toggleVideo())),
                  const SizedBox(width: 12),
                  _roundBtn(icon: Icons.cameraswitch, bg: Colors.white24, fg: Colors.white,
                    onTap: () => CallService.instance.switchCamera()),
                ],
              ])),
          ])));
      });
  }

  String _statusText(CallState s) {
    switch (s) {
      case CallState.outgoing: return 'Memanggil...';
      case CallState.incoming: return 'Panggilan masuk';
      case CallState.connecting: return 'Menyambungkan...';
      case CallState.active: return 'Terhubung';
      default: return '';
    }
  }

  Widget _roundBtn({required IconData icon, required Color bg, required Color fg, required VoidCallback onTap}) =>
    Material(color: bg, shape: const CircleBorder(),
      child: InkWell(customBorder: const CircleBorder(), onTap: onTap,
        child: Padding(padding: const EdgeInsets.all(18),
          child: Icon(icon, color: fg, size: 26))));
}
