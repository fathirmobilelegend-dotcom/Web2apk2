import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';
import '../services/notification_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  bool _register = false;
  bool _obscure = true;
  bool _loading = false;
  String? _err;

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() => _err = null);
    final u = _user.text.trim().toLowerCase();
    final p = _pass.text;
    final p2 = _pass2.text;
    if (u.isEmpty || p.isEmpty) { setState(() => _err = 'Username & password wajib diisi'); return; }
    if (!RegExp(r'^[a-z0-9_.-]{3,20}$').hasMatch(u)) { setState(() => _err = 'Username 3-20 karakter'); return; }
    if (_register) {
      if (p != p2) { setState(() => _err = 'Konfirmasi password tidak cocok'); return; }
      if (p.length < 3) { setState(() => _err = 'Password minimal 3 karakter'); return; }
    }
    setState(() => _loading = true);
    try {
      if (_register) {
        final r = await ApiService.register(u, p);
        final ok = r['success'] == true || r['ok'] == true || r['status'] == 'ok';
        if (!ok) throw ApiException(400, (r['msg'] ?? r['message'] ?? 'Gagal daftar').toString());
      }
      final r = await ApiService.login(u, p);
      if (r['banned'] == true) {
        if (!mounted) return;
        showModalBottomSheet(context: context, isScrollControlled: true,
          builder: (_) => _BanSheet(info: r['banInfo'] as Map<String, dynamic>? ?? {}, username: u));
        return;
      }
      final okLogin = r['success'] == true || r['ok'] == true || r['status'] == 'ok';
      if (!okLogin) {
        throw ApiException(400, (r['msg'] ?? r['message'] ?? 'Login gagal').toString());
      }
      final user = r['user'] as Map<String, dynamic>? ?? {};
      await AppState.instance.saveSession(
        username: u,
        sessionIdStr: (r['sessionId'] ?? r['session_id'] ?? '').toString(),
        display: user['displayName']?.toString(),
        avatarUrl: user['avatar'] as String?,
        bioText: user['bio']?.toString(),
        dev: user['isDev'] == true,
      );
      AppState.instance.loggedUser.value = u;
      // ✅ FIX: await permission notifikasi biar user liat dialognya
      await NotificationService.instance.requestPermissions();
      SocketService.instance.connect();
    } catch (e) {
      setState(() => _err = e is ApiException ? e.message : 'Gagal terhubung ke server');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0B141A) : const Color(0xFFF0F2F5);
    final cardBg = isDark ? const Color(0xFF111B21) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black87;
    final subColor = isDark ? Colors.grey.shade500 : Colors.grey.shade600;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(child: Center(child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Card(
          color: cardBg, elevation: 8,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: Padding(padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 72, height: 72,
                decoration: const BoxDecoration(shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [Color(0xFF00A884), Color(0xFF0088CC)])),
                child: const Icon(Icons.chat_bubble, color: Colors.white, size: 34)),
              const SizedBox(height: 14),
              Text('NexChat', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: textColor)),
              Text('Obrolan realtime, aman, dan cepat', style: TextStyle(color: subColor, fontSize: 13)),
              const SizedBox(height: 22),
              Container(
                decoration: BoxDecoration(
                  color: isDark ? Colors.grey.shade900 : Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.all(4),
                child: Row(children: [
                  Expanded(child: _tab('Masuk', !_register, isDark, () => setState(() => _register = false))),
                  Expanded(child: _tab('Daftar', _register, isDark, () => setState(() => _register = true))),
                ])),
              const SizedBox(height: 16),
              if (_err != null) Container(
                width: double.infinity, padding: const EdgeInsets.all(11),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF3A1515) : const Color(0xFFFDECEE),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFF15C6D).withOpacity(.4))),
                child: Text(_err!, style: TextStyle(color: isDark ? const Color(0xFFFF8A8A) : const Color(0xFFC62828)))),
              _field(_user, 'Username', Icons.alternate_email, isDark),
              const SizedBox(height: 12),
              _field(_pass, 'Password', Icons.lock_outline, isDark, obscure: _obscure,
                suffix: IconButton(
                  icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility, size: 20, color: subColor),
                  onPressed: () => setState(() => _obscure = !_obscure))),
              if (_register) ...[
                const SizedBox(height: 12),
                _field(_pass2, 'Konfirmasi Password', Icons.lock_outline, isDark, obscure: _obscure),
              ],
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, height: 50,
                child: ElevatedButton(
                  onPressed: _loading ? null : _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00A884), foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: _loading
                    ? const SizedBox(width: 22, height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_register ? 'Daftar' : 'Masuk',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)))),
            ])),
        ),
      ))),
    );
  }

  Widget _tab(String label, bool active, bool isDark, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: active ? const Color(0xFF00A884) : Colors.transparent,
        borderRadius: BorderRadius.circular(7)),
      child: Text(label, textAlign: TextAlign.center,
        style: TextStyle(fontWeight: FontWeight.w600,
          color: active ? Colors.white : (isDark ? Colors.grey.shade500 : Colors.grey.shade600)))));

  Widget _field(TextEditingController c, String label, IconData icon, bool isDark,
      {bool obscure = false, Widget? suffix}) {
    return TextField(
      controller: c, obscureText: obscure, autocorrect: false,
      textCapitalization: TextCapitalization.none,
      style: TextStyle(color: isDark ? Colors.white : Colors.black87),
      decoration: InputDecoration(
        labelText: label, labelStyle: TextStyle(color: isDark ? Colors.grey : Colors.grey.shade600),
        prefixIcon: Icon(icon, size: 20, color: isDark ? Colors.grey : Colors.grey.shade600),
        suffixIcon: suffix,
        filled: true,
        fillColor: isDark ? const Color(0xFF1A252C) : const Color(0xFFF0F2F5),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      ),
    );
  }
}

class _BanSheet extends StatefulWidget {
  final Map<String, dynamic> info;
  final String username;
  const _BanSheet({required this.info, required this.username});
  @override
  State<_BanSheet> createState() => _BanSheetState();
}

class _BanSheetState extends State<_BanSheet> {
  final _appeal = TextEditingController();
  bool _sending = false;
  bool _sent = false;

  @override
  Widget build(BuildContext context) {
    final b = widget.info;
    final permanent = b['permanent'] == true;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 60, height: 60,
              decoration: const BoxDecoration(shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Color(0xFFF15C6D), Color(0xFFC62828)])),
              child: const Icon(Icons.block, color: Colors.white, size: 30)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Akun Dibanned', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              Text('@${widget.username}', style: const TextStyle(color: Colors.grey)),
            ])),
          ]),
          const SizedBox(height: 18),
          _row('Tipe', permanent ? 'PERMANEN' : (b['type']?.toString() ?? '-')),
          _row('Alasan', b['reason']?.toString() ?? '-'),
          const SizedBox(height: 18),
          if (b['appealStatus'] == 'pending')
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFFFFF7E0), borderRadius: BorderRadius.circular(8)),
              child: const Text('⏳ Tinjauan sedang diproses developer...'))
          else if (_sent)
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFFE6F7EF), borderRadius: BorderRadius.circular(8)),
              child: const Text('✅ Tinjauan terkirim. Mohon tunggu keputusan.'))
          else ...[
            const Text('Ajukan tinjauan', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(controller: _appeal, maxLines: 4, maxLength: 1000,
              decoration: const InputDecoration(hintText: 'Jelaskan alasan...', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, height: 46,
              child: ElevatedButton.icon(
                onPressed: _sending ? null : _sendAppeal,
                icon: _sending ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send),
                label: const Text('Kirim Tinjauan'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00A884), foregroundColor: Colors.white))),
          ],
          const SizedBox(height: 8),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kembali')),
        ])),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 100, child: Text(label, style: const TextStyle(color: Colors.grey))),
      Expanded(child: Text(value)),
    ]));

  Future<void> _sendAppeal() async {
    final text = _appeal.text.trim();
    if (text.length < 10) return;
    setState(() => _sending = true);
    try {
      final r = await ApiService.submitAppeal(widget.username, text);
      if (r['success'] == true) setState(() => _sent = true);
    } catch (_) {}
    if (mounted) setState(() => _sending = false);
  }
}
