import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';

import '../app_state.dart';
import '../config.dart';
import '../services/api_service.dart';
import '../services/call_service.dart';
import '../services/socket_service.dart';
import '../widgets/avatar.dart';
import '../widgets/message_bubble.dart';
import '../widgets/theme_button.dart';
import 'call_screen.dart';

class ChatScreen extends StatefulWidget {
  final String partner;
  final bool isGroup;
  final bool isChannel;
  const ChatScreen({super.key, required this.partner, required this.isGroup, this.isChannel = false});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  final List<Map<String, dynamic>> _msgs = [];
  final Set<String> _seenIds = {};
  final Set<String> _pendingIds = {};
  final _input = TextEditingController();
  final _inputFocus = FocusNode();
  final _scroll = ScrollController();
  final _uuid = const Uuid();
  final _recorder = AudioRecorder();

  String _title = '';
  String? _titleAvatar;
  bool _isOnline = false;
  bool _isDev = false;
  Map<String, dynamic>? _group;
  Map<String, dynamic>? _replyTo;

  StreamSubscription? _msgSub, _statusSub, _delSub, _groupSub, _typingSub, _onlineSub;
  bool _otherTyping = false;
  Timer? _typingClear, _typingSendTimer;

  bool _recording = false;
  int _recSecs = 0;
  Timer? _recTimer;

  List<String> _mentionSuggestions = [];
  bool _showMentions = false;

  String get _chatId {
    if (widget.isChannel) return 'channel';
    if (widget.isGroup) return 'grp_${widget.partner}';
    final parts = [AppState.instance.loggedUser.value, widget.partner]..sort();
    return parts.join('_');
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppState.instance.openChatId.value = _chatId;
    _loadHeader();
    _loadHistory();
    _listen();
    _setViewing(true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AppState.instance.openChatId.value = '';
    _setViewing(false);
    _msgSub?.cancel(); _statusSub?.cancel(); _delSub?.cancel();
    _groupSub?.cancel(); _typingSub?.cancel(); _onlineSub?.cancel();
    _typingClear?.cancel(); _typingSendTimer?.cancel();
    _recTimer?.cancel();
    try { _recorder.dispose(); } catch (_) {}
    _input.dispose();
    _inputFocus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _setViewing(true);
    }
  }

  void _setViewing(bool on) {
    final partner = widget.isChannel
        ? 'channel'
        : (widget.isGroup ? 'grp_${widget.partner}' : widget.partner);
    SocketService.instance.viewing(on ? partner : null);

    if (on) {
      AppState.instance.markChatRead(
        partner: widget.partner,
        isGroup: widget.isGroup,
        isChannel: widget.isChannel,
      );
      ApiService.markRead(
        username: AppState.instance.loggedUser.value,
        partner: widget.partner,
        isGroup: widget.isGroup,
        isChannel: widget.isChannel,
      ).catchError((_) => <String, dynamic>{});
      Future.delayed(const Duration(milliseconds: 250), () {
        if (mounted) SocketService.instance.refreshChatList();
      });
    }
  }

  void _listen() {
    _msgSub = SocketService.instance.messageStream.listen((d) {
      final myUser = AppState.instance.loggedUser.value;
      final from = (d['from'] ?? '').toString();
      final isGroup = d['isGroup'] == true;
      final isChannel = d['isChannel'] == true;
      final partner = isChannel ? 'channel'
        : (isGroup ? (d['to'] ?? '').toString()
          : (from == myUser ? (d['to'] ?? '').toString() : from));
      final ok = widget.isChannel ? isChannel
        : widget.isGroup ? (isGroup && partner == widget.partner)
        : (!isGroup && !isChannel && partner == widget.partner);
      if (!ok) return;
      _handleIncomingMessage(Map<String, dynamic>.from(d));
    });
    _statusSub = SocketService.instance.statusStream.listen((d) {
      if (d['status'] == 'read' && d['ids'] is List) {
        final ids = (d['ids'] as List).map((e) => e.toString()).toSet();
        setState(() {
          for (final m in _msgs) {
            if (ids.contains(m['id'])) {
              final rb = (m['readBy'] as List? ?? []).map((e) => e.toString()).toList();
              if (!rb.contains('peer')) rb.add('peer');
              m['readBy'] = rb;
            }
          }
        });
      } else if (d['status'] == 'delivered' && d['id'] != null) {
        setState(() {
          for (final m in _msgs) {
            if (m['id'] == d['id']) {
              final dt = (m['deliveredTo'] as List? ?? []).map((e) => e.toString()).toList();
              if (!dt.contains('peer')) dt.add('peer');
              m['deliveredTo'] = dt;
            }
          }
        });
      } else if (d['user'] != null && d['user'].toString().toLowerCase() == widget.partner.toLowerCase()) {
        setState(() => _isOnline = d['status'] == 'online');
      }
    });
    _delSub = SocketService.instance.msgDeleteStream.listen((d) {
      if (d['chatId'] != _chatId) return;
      setState(() {
        final id = d['messageId'];
        for (final m in _msgs) {
          if (m['id'] == id) {
            if (d['forMe'] == true) _msgs.remove(m);
            else { m['deletedForEveryone'] = true; m['text'] = ''; m['file'] = null; }
            break;
          }
        }
      });
    });
    _groupSub = SocketService.instance.groupStream.listen((d) {
      if (widget.isGroup && (d['group']?['id'] == widget.partner)) {
        setState(() => _group = Map<String, dynamic>.from(d['group'] as Map));
        _loadHeader();
      }
    });
    _typingSub = SocketService.instance.typingStream.listen((d) {
      final isGroupMsg = d['isGroup'] == true;
      final isTypingNow = d['isTyping'] == true;
      if (widget.isGroup) {
        if (isGroupMsg && d['groupId'] == widget.partner && isTypingNow) _pingTyping();
      } else {
        if (!isGroupMsg && d['from'] == widget.partner && isTypingNow) _pingTyping();
      }
    });
    // ✅ FIX: dengerin online status peer
    _onlineSub = SocketService.instance.onlineStream.listen((d) {
      final user = (d['user'] ?? d['username'] ?? '').toString();
      if (user.toLowerCase() != widget.partner.toLowerCase()) return;
      final online = (d['status'] == 'online') || d['online'] == true;
      setState(() => _isOnline = online);
      AppState.instance.updatePeerOnline(widget.partner, online);
    });
  }

  // ✅ FIX: match echo server dengan optimis message
  void _handleIncomingMessage(Map<String, dynamic> d) {
    final myUser = AppState.instance.loggedUser.value;
    final from = (d['from'] ?? '').toString();
    final serverId = d['id']?.toString();

    // Kalau pesan dari kita sendiri (echo server)
    if (from == myUser && serverId != null) {
      // 1. Cek ID match persis
      if (_pendingIds.contains(serverId)) {
        _pendingIds.remove(serverId);
        _seenIds.add(serverId);
        _mergeMessageById(serverId, d);
        return;
      }
      // 2. Fallback: match by content + type
      final pendingIdx = _msgs.indexWhere((m) {
        final mid = m['id']?.toString();
        if (mid == null || !_pendingIds.contains(mid)) return false;
        return (m['text'] ?? '') == (d['text'] ?? '') &&
               (m['msgType'] ?? 'text') == (d['msgType'] ?? 'text');
      });
      if (pendingIdx >= 0) {
        final oldId = _msgs[pendingIdx]['id']?.toString();
        setState(() {
          _msgs[pendingIdx] = {..._msgs[pendingIdx], ...d, 'id': serverId};
        });
        if (oldId != null) _pendingIds.remove(oldId);
        _seenIds.add(serverId);
        return;
      }
    }

    // Pesan baru / duplikat
    if (serverId != null) {
      if (_seenIds.contains(serverId)) {
        _mergeMessageById(serverId, d);
        return;
      }
      _seenIds.add(serverId);
    }
    setState(() => _msgs.add(d));
    _scrollToBottom();
    _setViewing(true);
  }

  void _mergeMessageById(String id, Map<String, dynamic> d) {
    final idx = _msgs.indexWhere((x) => x['id']?.toString() == id);
    if (idx < 0) return;
    final existing = _msgs[idx];
    final merged = {...existing, ...d};
    if (existing['timestamp'] != null && existing['timestamp'] != d['timestamp']) {
      merged['timestamp'] = existing['timestamp'];
    }
    setState(() { _msgs[idx] = merged; });
  }

  void _pingTyping() {
    setState(() => _otherTyping = true);
    _typingClear?.cancel();
    _typingClear = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _otherTyping = false);
    });
  }

  Future<void> _loadHeader() async {
    if (widget.isChannel) { setState(() => _title = 'Informasi Penting'); return; }
    if (widget.isGroup) {
      try {
        final r = await ApiService.group(widget.partner);
        if (r['exists'] == true) {
          setState(() {
            _group = Map<String, dynamic>.from(r['group'] as Map);
            _title = (_group!['name'] ?? 'Grup').toString();
            _titleAvatar = _group!['avatar'] as String?;
          });
        }
      } catch (_) {}
    } else {
      try {
        final p = await ApiService.profile(widget.partner, viewer: AppState.instance.loggedUser.value);
        if (p['exists'] == true) {
          setState(() {
            _title = (p['displayName'] ?? widget.partner).toString();
            _titleAvatar = p['avatar'] as String?;
            _isOnline = p['isOnline'] == true;
            _isDev = p['isDev'] == true;
          });
          AppState.instance.updatePeerOnline(widget.partner, _isOnline);
        }
      } catch (_) {}
    }
  }

  // ✅ FIX: MERGE, jangan replace. Pesan optimis gak akan hilang
  Future<void> _loadHistory() async {
    try {
      List<dynamic> msgs;
      if (widget.isChannel) {
        final r = await ApiService.channelHistory(AppState.instance.loggedUser.value);
        msgs = (r['messages'] as List?) ?? [];
      } else if (widget.isGroup) {
        msgs = await ApiService.groupHistory(widget.partner, AppState.instance.loggedUser.value);
      } else {
        msgs = await ApiService.chatHistory(AppState.instance.loggedUser.value, widget.partner);
      }

      final serverMsgs = <Map<String, dynamic>>[];
      final serverIds = <String>{};
      for (final m in msgs) {
        final mm = Map<String, dynamic>.from(m as Map);
        final id = mm['id']?.toString();
        if (id != null) serverIds.add(id);
        serverMsgs.add(mm);
      }

      // Kumpulkan pesan optimis yang belum ada di server
      final pendingLocals = _msgs.where((m) {
        final id = m['id']?.toString();
        return id != null && _pendingIds.contains(id) && !serverIds.contains(id);
      }).toList();

      final merged = <Map<String, dynamic>>[];
      merged.addAll(serverMsgs);
      merged.addAll(pendingLocals);

      setState(() {
        _msgs.clear();
        _msgs.addAll(merged);
        _seenIds.clear();
        _seenIds.addAll(serverIds);
        for (final m in pendingLocals) {
          final id = m['id']?.toString();
          if (id != null) _seenIds.add(id);
        }
      });
      _scrollToBottom();
      _setViewing(true);
    } catch (_) {}
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  void _pushLastMsgToChatList(Map<String, dynamic> msg) {
    AppState.instance.setLocalLastMsg(
      partner: widget.isChannel ? 'channel' : widget.partner,
      isGroup: widget.isGroup,
      isChannel: widget.isChannel,
      msg: msg,
    );
  }

  Future<void> _send({String type = 'text', String text = '', Map<String, dynamic>? file}) async {
    if (widget.isChannel && !AppState.instance.isDev.value) return;
    final id = _uuid.v4();
    final myUser = AppState.instance.loggedUser.value;
    final localMsg = {
      'id': id, 'from': myUser,
      'fromName': AppState.instance.displayName.value.isEmpty
        ? myUser : AppState.instance.displayName.value,
      'fromDev': AppState.instance.isDev.value,
      'to': widget.isChannel ? 'channel' : widget.partner,
      'isGroup': widget.isGroup, 'isChannel': widget.isChannel,
      'msgType': type, 'text': text,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'readBy': <String>[], 'deliveredTo': <String>[],
      if (file != null) 'file': file,
      if (_replyTo != null) 'replyTo': _replyTo,
    };
    _pendingIds.add(id);
    _seenIds.add(id);
    setState(() => _msgs.add(localMsg));
    _scrollToBottom();
    _pushLastMsgToChatList(localMsg);
    SocketService.instance.sendMessage(
      to: widget.isChannel ? 'channel' : widget.partner,
      id: id, msgType: type, text: text, file: file, replyTo: _replyTo,
      isGroup: widget.isGroup, isChannel: widget.isChannel);
    // ✅ FIX: refresh chat list setelah kirim biar realtime
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) SocketService.instance.refreshChatList();
    });
    setState(() => _replyTo = null);
    _input.clear();
    _showMentions = false;
    _mentionSuggestions = [];
  }

  void _onTextChanged(String v) {
    if (v.trim().isEmpty) {
      _showMentions = false;
      _mentionSuggestions = [];
      setState(() {});
      return;
    }
    if (widget.isGroup) {
      final mentionMatch = RegExp(r'@(w*)$').firstMatch(v);
      if (mentionMatch != null) {
        final q = mentionMatch.group(1)?.toLowerCase() ?? '';
        final members = (_group?['members'] as List?) ?? [];
        final filtered = members
          .map((m) => (m['username'] ?? '').toString())
          .where((u) => u.toLowerCase().contains(q))
          .toList();
        setState(() {
          _mentionSuggestions = filtered;
          _showMentions = filtered.isNotEmpty;
        });
      } else {
        _showMentions = false;
        _mentionSuggestions = [];
        setState(() {});
      }
    }
    _typingSendTimer ??= Timer(const Duration(milliseconds: 300), () {
      _typingSendTimer = null;
      SocketService.instance.typing(widget.partner, isGroup: widget.isGroup, isTyping: true);
      Timer(const Duration(seconds: 3), () {
        SocketService.instance.typing(widget.partner, isGroup: widget.isGroup, isTyping: false);
      });
    });
  }

  void _insertMention(String username) {
    final cur = _input.text;
    final idx = cur.lastIndexOf('@');
    if (idx >= 0) {
      final newText = '${cur.substring(0, idx)}@$username ';
      _input.text = newText;
      _input.selection = TextSelection.fromPosition(TextPosition(offset: newText.length));
    }
    setState(() {
      _showMentions = false;
      _mentionSuggestions = [];
    });
    _inputFocus.requestFocus();
  }

  Future<void> _startVoiceRecord() async {
    try {
      if (!await _recorder.hasPermission()) { _toast('Izin mic ditolak'); return; }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
      setState(() { _recording = true; _recSecs = 0; });
      _recTimer?.cancel();
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recSecs++);
        if (_recSecs >= 120) _stopVoiceRecord(send: true);
      });
    } catch (e) { _toast('Gagal mulai record: $e'); }
  }

  Future<void> _stopVoiceRecord({required bool send}) async {
    if (!_recording) return;
    try {
      final path = await _recorder.stop();
      _recTimer?.cancel();
      final secs = _recSecs;
      setState(() { _recording = false; _recSecs = 0; });
      if (!send || path == null || secs < 1) {
        try { if (path != null) File(path).delete(); } catch (_) {}
        return;
      }
      final file = File(path);
      if (await file.length() < 500) return;
      final bytes = await file.readAsBytes();
      _toast('Mengirim VN...');
      await _uploadAndSendVoice(bytes, secs);
    } catch (e) { _toast('Gagal stop: $e'); }
  }

  Future<void> _uploadAndSendVoice(List<int> bytes, int duration) async {
    try {
      final uri = Uri.parse('${AppConfig.backendUrl}/api/upload');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: 'vn_${DateTime.now().millisecondsSinceEpoch}.m4a'));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      final r = jsonDecode(body) as Map<String, dynamic>;
      if (r['success'] == true) {
        final file = Map<String, dynamic>.from(r['file'] as Map);
        file['duration'] = duration;
        file['mime'] = 'audio/mp4';
        await _send(type: 'voice', file: file);
      } else { _toast('Upload VN gagal'); }
    } catch (e) { _toast('Gagal: $e'); }
  }

  Future<void> _pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1600);
    if (x == null) return;
    await _showPreviewAndSend(x);
  }

  Future<void> _pickFile() async {
    final res = await FilePicker.platform.pickFiles();
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.size > AppConfig.maxUpload) { _toast('File terlalu besar (max 200MB)'); return; }
    final bytes = f.bytes ?? await File(f.path!).readAsBytes();
    _toast('Mengunggah...');
    await _uploadAndSendFile(bytes, f.name);
  }

  Future<void> _uploadAndSendFile(List<int> bytes, String name) async {
    try {
      final uri = Uri.parse('${AppConfig.backendUrl}/api/upload');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: name));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      final r = jsonDecode(body) as Map<String, dynamic>;
      if (r['success'] == true) {
        await _send(type: 'file', file: Map<String, dynamic>.from(r['file'] as Map));
      } else _toast('Upload gagal');
    } catch (e) { _toast('Gagal: $e'); }
  }

  Future<void> _showPreviewAndSend(XFile x) async {
    final captionC = TextEditingController();
    if (!mounted) return;
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        contentPadding: const EdgeInsets.all(12),
        title: const Text('Kirim ke...'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(File(x.path), height: 200, fit: BoxFit.cover),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: captionC,
            maxLines: 3,
            maxLength: 300,
            decoration: const InputDecoration(
              hintText: 'Tambahkan keterangan...',
              border: OutlineInputBorder(),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Kirim')),
        ],
      ),
    );
    if (result != true) return;
    final caption = captionC.text.trim();
    _toast('Mengunggah...');
    try {
      final bytes = await x.readAsBytes();
      final uri = Uri.parse('${AppConfig.backendUrl}/api/upload');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: x.name));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      final r = jsonDecode(body) as Map<String, dynamic>;
      if (r['success'] == true) {
        await _send(
          type: 'file',
          text: caption,
          file: Map<String, dynamic>.from(r['file'] as Map));
      } else _toast('Upload gagal');
    } catch (e) { _toast('Gagal: $e'); }
  }

  Future<void> _openCameraSheet() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.black,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text('Kirim Media',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16)),
          ),
          const Divider(height: 1, color: Colors.white24),
          ListTile(
            leading: const Icon(Icons.camera_alt, color: Color(0xFF00A884)),
            title: const Text('Kamera', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context, 'camera'),
          ),
          ListTile(
            leading: const Icon(Icons.image, color: Color(0xFF00A884)),
            title: const Text('Galeri', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context, 'gallery'),
          ),
          ListTile(
            leading: const Icon(Icons.videocam, color: Color(0xFF00A884)),
            title: const Text('Video', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context, 'video'),
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (choice == null) return;
    if (choice == 'camera') {
      final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85, maxWidth: 1600);
      if (x == null) return;
      await _showPreviewAndSend(x);
    } else if (choice == 'gallery') {
      await _pickImage();
    } else if (choice == 'video') {
      final x = await ImagePicker().pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 1));
      if (x == null) return;
      _toast('Mengunggah video...');
      try {
        final bytes = await x.readAsBytes();
        await _uploadAndSendFile(bytes, x.name);
      } catch (e) { _toast('Gagal: $e'); }
    }
  }

  Future<void> _downloadFile(String url, String filename) async {
    try {
      _toast('Mengunduh...');
      final fullUrl = url.startsWith('http') ? url : '${AppConfig.backendUrl}$url';
      final dir = await getApplicationDocumentsDirectory();
      final downloadsDir = Directory('${dir.path}/NexChat');
      if (!await downloadsDir.exists()) await downloadsDir.create(recursive: true);
      final filePath = '${downloadsDir.path}/${DateTime.now().millisecondsSinceEpoch}_$filename';
      final res = await http.get(Uri.parse(fullUrl));
      if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
      await File(filePath).writeAsBytes(res.bodyBytes);
      _toast('Tersimpan: $filePath');
    } catch (e) { _toast('Gagal download: $e'); }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  void _startCall({required bool isVideo}) {
    if (widget.isGroup || widget.isChannel) return;
    CallService.instance.startCall(
      to: widget.partner, displayName: _title.isEmpty ? widget.partner : _title,
      avatarUrl: _titleAvatar, isVideo: isVideo);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CallScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        titleSpacing: 0,
        title: Row(children: [
          AppAvatar(name: _title.isEmpty ? widget.partner : _title, url: _titleAvatar,
            size: 38, isChannel: widget.isChannel),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Flexible(child: Text(_title.isEmpty ? widget.partner : _title,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
              if (_isDev) ...[
                const SizedBox(width: 4),
                const Icon(Icons.verified, size: 15, color: Color(0xFF53BDEB)),
              ],
            ]),
            Text(_subtitle(), maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12,
                color: _isOnline && !widget.isGroup && !widget.isChannel
                  ? const Color(0xFF00E5A0) : Colors.grey,
                fontStyle: _otherTyping ? FontStyle.italic : FontStyle.normal)),
          ])),
        ]),
        actions: [
          if (!widget.isGroup && !widget.isChannel) ...[
            IconButton(icon: const Icon(Icons.phone), onPressed: () => _startCall(isVideo: false)),
            IconButton(icon: const Icon(Icons.videocam), onPressed: () => _startCall(isVideo: true)),
          ],
          const ThemeButton(),
        ],
      ),
      body: Column(children: [
        if (widget.isChannel && !AppState.instance.isDev.value)
          Container(color: const Color(0x1A00A884), padding: const EdgeInsets.all(10),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.info_outline, size: 16, color: Color(0xFF00A884)),
              SizedBox(width: 6),
              Text('Hanya developer yang bisa mengirim pesan di channel ini', style: TextStyle(fontSize: 12)),
            ])),
        Expanded(child: Container(
          color: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF0B1418) : const Color(0xFFEFEAE2),
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
            itemCount: _msgs.length + (_otherTyping ? 1 : 0),
            itemBuilder: (_, i) {
              if (i == _msgs.length) return const Padding(
                padding: EdgeInsets.all(8),
                child: Align(alignment: Alignment.centerLeft, child: _TypingBubble()));
              final m = _msgs[i];
              // ✅ FIX: inject peerOnline untuk C1/C2
              return MessageBubble(
                msg: m, isGroup: widget.isGroup, isChannel: widget.isChannel,
                peerOnline: _isOnline || AppState.instance.isPeerOnline(widget.partner),
                onReply: (mm) => _setReply(mm),
                onLongPress: () => _showMsgMenu(m),
                onDownload: _downloadFile,
                onJumpTo: (_) {});
            },
          ),
        )),
        if (_showMentions) _buildMentionSuggestions(),
        if (_replyTo != null) _buildReplyBar(),
        if (_recording) _buildRecordingIndicator(),
        _buildInputBar(),
      ]),
    );
  }

  void _setReply(Map<String, dynamic> m) {
    setState(() => _replyTo = m);
    _inputFocus.requestFocus();
  }

  String _subtitle() {
    if (_otherTyping) return 'mengetik...';
    if (widget.isChannel) return 'Channel resmi NexChat';
    if (widget.isGroup) {
      final count = (_group?['members'] as List?)?.length ?? 0;
      return '$count anggota';
    }
    return _isOnline ? 'Online' : 'offline';
  }

  Widget _buildMentionSuggestions() {
    final theme = Theme.of(context);
    return Container(
      constraints: const BoxConstraints(maxHeight: 180),
      color: theme.appBarTheme.backgroundColor,
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: _mentionSuggestions.length,
        itemBuilder: (_, i) {
          final u = _mentionSuggestions[i];
          return ListTile(
            dense: true,
            leading: const Icon(Icons.alternate_email, size: 18),
            title: Text('@$u', style: const TextStyle(fontSize: 14)),
            onTap: () => _insertMention(u),
          );
        },
      ),
    );
  }

  Widget _buildReplyBar() {
    final m = _replyTo!;
    final from = (m['from'] ?? '').toString() == AppState.instance.loggedUser.value
      ? 'Anda' : (m['fromName'] ?? m['from'] ?? '').toString();
    final preview = _previewOf(m);
    final theme = Theme.of(context);
    return Container(
      color: theme.appBarTheme.backgroundColor,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(children: [
        Container(width: 3, height: 34, color: const Color(0xFF00A884)),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(from, style: const TextStyle(color: Color(0xFF00A884), fontSize: 12, fontWeight: FontWeight.w600)),
          Text(preview, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.grey, fontSize: 12)),
        ])),
        IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => _replyTo = null)),
      ]));
  }

  Widget _buildRecordingIndicator() {
    final m = _recSecs ~/ 60;
    final s = (_recSecs % 60).toString().padLeft(2, '0');
    return Container(
      color: const Color(0xFF1A0000),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(children: [
        Container(width: 8, height: 8,
          decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
        const SizedBox(width: 8),
        const Text('Merekam...', style: TextStyle(color: Colors.white)),
        const Spacer(),
        Text('$m:$s', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(width: 10),
        IconButton(icon: const Icon(Icons.delete, color: Colors.red),
          onPressed: () => _stopVoiceRecord(send: false)),
        IconButton(icon: const Icon(Icons.send, color: Color(0xFF00A884)),
          onPressed: () => _stopVoiceRecord(send: true)),
      ]),
    );
  }

  String _previewOf(Map<String, dynamic> m) {
    final t = (m['msgType'] ?? 'text').toString();
    if (t == 'file') return '📎 ${m['file']?['name'] ?? 'File'}';
    if (t == 'voice') return '🎤 Pesan suara';
    return (m['text'] ?? '').toString();
  }

  Widget _buildInputBar() {
    final disabled = widget.isChannel && !AppState.instance.isDev.value;
    if (disabled) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    if (_recording) return const SizedBox.shrink();

    return SafeArea(top: false,
      child: Container(
        color: theme.appBarTheme.backgroundColor,
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          IconButton(icon: const Icon(Icons.attach_file), onPressed: _pickFile, tooltip: 'File'),
          IconButton(icon: const Icon(Icons.camera_alt_outlined), onPressed: _openCameraSheet, tooltip: 'Kamera'),
          Expanded(child: TextField(
            controller: _input, focusNode: _inputFocus,
            minLines: 1, maxLines: 5, onChanged: _onTextChanged,
            textInputAction: TextInputAction.newline,
            style: TextStyle(color: isDark ? Colors.white : Colors.black87),
            decoration: InputDecoration(
              hintText: 'Ketik pesan...',
              hintStyle: TextStyle(color: Colors.grey.shade500),
              filled: true,
              fillColor: isDark ? const Color(0xFF2A3942) : const Color(0xFFF0F2F5),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
          StreamBuilder<bool>(
            stream: Stream.periodic(const Duration(milliseconds: 300)).map((_) => _input.text.trim().isEmpty),
            initialData: true,
            builder: (_, snap) {
              final empty = snap.data ?? true;
              if (empty) {
                return IconButton(icon: const Icon(Icons.mic), onPressed: _startVoiceRecord, tooltip: 'Voice Note');
              }
              return Material(color: const Color(0xFF00A884), shape: const CircleBorder(),
                child: InkWell(customBorder: const CircleBorder(),
                  onTap: () {
                    final t = _input.text.trim();
                    if (t.isEmpty) return;
                    _send(text: t);
                  },
                  child: const Padding(padding: EdgeInsets.all(10),
                    child: Icon(Icons.send, color: Colors.white, size: 20))));
            },
          ),
        ])));
  }

  Future<void> _showMsgMenu(Map<String, dynamic> m) async {
    final isMe = (m['from'] ?? '').toString() == AppState.instance.loggedUser.value;
    if (m['deletedForEveryone'] == true) return;
    final items = <Widget>[
      ListTile(leading: const Icon(Icons.reply), title: const Text('Balas'),
        onTap: () { Navigator.pop(context); _setReply(m); }),
      if (m['msgType'] == 'file' && m['file'] != null && m['file']['url'] != null)
        ListTile(leading: const Icon(Icons.download), title: const Text('Download'),
          onTap: () { Navigator.pop(context); _downloadFile(m['file']['url'].toString(), m['file']['name'].toString()); }),
      if (m['msgType'] == 'file' && m['file'] != null && m['file']['url'] != null)
        ListTile(leading: const Icon(Icons.open_in_new), title: const Text('Buka di browser'),
          onTap: () {
            Navigator.pop(context);
            final u = m['file']['url'].toString();
            final fullUrl = u.startsWith('http') ? u : '${AppConfig.backendUrl}$u';
            launchUrl(Uri.parse(fullUrl), mode: LaunchMode.externalApplication);
          }),
      ListTile(leading: const Icon(Icons.delete, color: Colors.red),
        title: const Text('Hapus untuk saya', style: TextStyle(color: Colors.red)),
        onTap: () async {
          Navigator.pop(context);
          await ApiService.deleteMessage(AppState.instance.loggedUser.value, _chatId, m['id'].toString());
          setState(() => _msgs.remove(m));
        }),
      if (isMe) ListTile(leading: const Icon(Icons.delete_forever, color: Colors.red),
        title: const Text('Hapus untuk semua', style: TextStyle(color: Colors.red)),
        onTap: () async {
          Navigator.pop(context);
          await ApiService.deleteMessage(AppState.instance.loggedUser.value, _chatId,
            m['id'].toString(), forEveryone: true);
        }),
    ];
    showModalBottomSheet(context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: items)));
  }
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(
      color: Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF202C33) : Colors.white,
      borderRadius: BorderRadius.circular(14)),
    child: const Row(mainAxisSize: MainAxisSize.min, children: [
      _Dot(delay: 0), SizedBox(width: 4), _Dot(delay: 150), SizedBox(width: 4), _Dot(delay: 300),
    ]));
}

class _Dot extends StatefulWidget {
  final int delay;
  const _Dot({required this.delay});
  @override
  State<_Dot> createState() => _DotState();
}

class _DotState extends State<_Dot> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: _c,
    builder: (_, __) {
      final t = (1 - (_c.value - 0.5).abs() * 2).clamp(0.0, 1.0);
      return Transform.translate(offset: Offset(0, -3 * t),
        child: Container(width: 6, height: 6,
          decoration: BoxDecoration(color: Colors.grey.shade400, shape: BoxShape.circle)));
    });
}
