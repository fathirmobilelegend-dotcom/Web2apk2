import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import '../app_state.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';
import '../widgets/avatar.dart';
import '../widgets/theme_button.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});
  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  bool _savingAvatar = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: const [ThemeButton()]),
      body: ListView(children: [
        const SizedBox(height: 12),
        _buildAvatarSection(),
        const SizedBox(height: 14),
        _buildNameSection(),
        _buildUsernameSection(),
        const SizedBox(height: 20),
        _buildDisplayNameTile(),
        _buildBioTile(),
        _buildLogoutTile(),
      ]),
    );
  }

  Widget _buildAvatarSection() {
    return Center(child: GestureDetector(
      onTap: _savingAvatar ? null : _changeAvatar,
      child: Stack(children: [
        ValueListenableBuilder<String>(
          valueListenable: AppState.instance.displayName,
          builder: (_, dn, __) => ValueListenableBuilder<String?>(
            valueListenable: AppState.instance.avatar,
            builder: (_, av, __) => AppAvatar(
              name: dn.isEmpty ? AppState.instance.loggedUser.value : dn,
              url: av, size: 120))),
        Positioned(bottom: 0, right: 0,
          child: Container(padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(color: Color(0xFF00A884), shape: BoxShape.circle),
            child: _savingAvatar
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.camera_alt, color: Colors.white, size: 18))),
      ])));
  }

  Widget _buildNameSection() => Center(child: ValueListenableBuilder<String>(
    valueListenable: AppState.instance.displayName,
    builder: (_, dn, __) => Text(dn.isEmpty ? AppState.instance.loggedUser.value : dn,
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600))));

  Widget _buildUsernameSection() => Center(child: ValueListenableBuilder<String>(
    valueListenable: AppState.instance.loggedUser,
    builder: (_, u, __) => Text('@$u', style: const TextStyle(color: Colors.grey))));

  Widget _buildDisplayNameTile() => ListTile(
    leading: const Icon(Icons.edit_note),
    title: const Text('Nama panggilan'),
    subtitle: ValueListenableBuilder<String>(
      valueListenable: AppState.instance.displayName,
      builder: (_, dn, __) => Text(dn.isEmpty ? '-' : dn)),
    trailing: const Icon(Icons.edit, size: 18),
    onTap: _editDisplayName);

  Widget _buildBioTile() => ListTile(
    leading: const Icon(Icons.format_quote),
    title: const Text('Bio'),
    subtitle: ValueListenableBuilder<String>(
      valueListenable: AppState.instance.bio,
      builder: (_, b, __) => Text(b.isEmpty ? '-' : b)),
    trailing: const Icon(Icons.edit, size: 18),
    onTap: _editBio);

  Widget _buildLogoutTile() => ListTile(
    leading: const Icon(Icons.logout, color: Colors.red),
    title: const Text('Logout', style: TextStyle(color: Colors.red)),
    onTap: _logout);

  Future<void> _changeAvatar() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery,
        maxWidth: 512, maxHeight: 512, imageQuality: 75);
      if (x == null) return;
      setState(() => _savingAvatar = true);
      final bytes = await x.readAsBytes();
      if (bytes.length > 2 * 1024 * 1024) {
        if (mounted) setState(() => _savingAvatar = false);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gambar terlalu besar (max 2MB)')));
        return;
      }
      final isPng = x.name.toLowerCase().endsWith('.png');
      final mime = isPng ? 'image/png' : 'image/jpeg';
      final b64 = 'data:$mime;base64,${base64Encode(bytes)}';
      final r = await ApiService.updateProfile(
        username: AppState.instance.loggedUser.value, avatar: b64);
      if (r['success'] == true) {
        await AppState.instance.updateProfile(avatarUrl: b64);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto profil diubah')));
      } else {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(r['msg']?.toString() ?? 'Gagal simpan foto')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal: $e')));
    } finally {
      if (mounted) setState(() => _savingAvatar = false);
    }
  }

  Future<void> _editDisplayName() async {
    final c = TextEditingController(text: AppState.instance.displayName.value);
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Nama panggilan'),
      content: TextField(controller: c, maxLength: 40, autofocus: true,
        decoration: const InputDecoration(hintText: 'Nama kamu')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan')),
      ]));
    if (ok != true) return;
    final name = c.text.trim();
    await ApiService.updateProfile(username: AppState.instance.loggedUser.value, displayName: name);
    await AppState.instance.updateProfile(display: name);
    if (mounted) setState(() {});
  }

  Future<void> _editBio() async {
    final c = TextEditingController(text: AppState.instance.bio.value);
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Bio'),
      content: TextField(controller: c, maxLength: 150, maxLines: 3, autofocus: true,
        decoration: const InputDecoration(hintText: 'Tentang kamu...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan')),
      ]));
    if (ok != true) return;
    final bio = c.text.trim();
    await ApiService.updateProfile(username: AppState.instance.loggedUser.value, bio: bio);
    await AppState.instance.updateProfile(bioText: bio);
    if (mounted) setState(() {});
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Logout'),
      content: const Text('Yakin ingin keluar?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true),
          child: const Text('Keluar', style: TextStyle(color: Colors.red))),
      ]));
    if (ok != true) return;
    SocketService.instance.disconnect();
    await AppState.instance.clear();
    if (mounted) setState(() {});
  }
}
