import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';
import '../widgets/theme_button.dart';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pengaturan', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: const [ThemeButton()]),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.palette_outlined),
          title: const Text('Tema'),
          subtitle: ValueListenableBuilder<String>(
            valueListenable: AppState.instance.theme,
            builder: (_, t, __) => Text('Sekarang: $t')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => showThemePicker(context)),
        ListTile(leading: const Icon(Icons.lock_outline), title: const Text('Ganti password'),
          onTap: () => _changePassword(context)),
        ListTile(leading: const Icon(Icons.shield_outlined), title: const Text('Riwayat login'),
          onTap: () => _sessions(context)),
        ListTile(leading: const Icon(Icons.block), title: const Text('Daftar diblokir'),
          onTap: () => _blocks(context)),
        const Divider(),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('Tentang'),
          subtitle: const Text('NexChat v1.0.0')),
        ListTile(leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('Logout', style: TextStyle(color: Colors.red)),
          onTap: () async {
            SocketService.instance.disconnect();
            await AppState.instance.clear();
          }),
      ]));
  }

  Future<void> _changePassword(BuildContext context) async {
    final c1 = TextEditingController(); final c2 = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Ganti password'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: c1, obscureText: true,
          decoration: const InputDecoration(labelText: 'Password baru')),
        TextField(controller: c2, obscureText: true,
          decoration: const InputDecoration(labelText: 'Konfirmasi')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan')),
      ]));
    if (ok != true) return;
    if (c1.text != c2.text) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password tidak cocok')));
      return;
    }
    await ApiService.changePassword(AppState.instance.loggedUser.value, c1.text);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password diubah')));
  }

  Future<void> _sessions(BuildContext context) async {
    final list = await ApiService.sessions(AppState.instance.loggedUser.value);
    if (!context.mounted) return;
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Riwayat login'),
      content: SizedBox(width: double.maxFinite,
        child: ListView.builder(shrinkWrap: true, itemCount: list.length,
          itemBuilder: (_, i) {
            final s = Map<String, dynamic>.from(list[i] as Map);
            return ListTile(
              title: Text((s['ua'] ?? 'Unknown').toString(), maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text((s['ip'] ?? '-').toString()),
              trailing: IconButton(icon: const Icon(Icons.close, color: Colors.red),
                onPressed: () async {
                  await ApiService.logoutSession(AppState.instance.loggedUser.value, s['id'].toString());
                }));
          })),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))]));
  }

  Future<void> _blocks(BuildContext context) async {
    final list = await ApiService.blocks(AppState.instance.loggedUser.value);
    if (!context.mounted) return;
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Daftar diblokir'),
      content: list.isEmpty ? const Text('Belum ada')
        : SizedBox(width: double.maxFinite,
          child: ListView.builder(shrinkWrap: true, itemCount: list.length,
            itemBuilder: (_, i) => ListTile(
              title: Text('@${list[i]}'),
              trailing: TextButton(
                onPressed: () async {
                  await ApiService.unblock(AppState.instance.loggedUser.value, list[i].toString());
                  if (context.mounted) Navigator.pop(context);
                }, child: const Text('Buka'))))),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))]));
  }
}
