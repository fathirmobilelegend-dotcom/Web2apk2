import 'dart:async';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';
import '../services/notification_service.dart';
import '../widgets/avatar.dart';
import '../widgets/theme_button.dart';
import 'chat_screen.dart';

class ChatListTab extends StatefulWidget {
  const ChatListTab({super.key});
  @override
  State<ChatListTab> createState() => _ChatListTabState();
}

class _ChatListTabState extends State<ChatListTab> {
  List<Map<String, dynamic>> _items = [];
  final Map<String, bool> _typingPeers = {};
  final Map<String, Map<String, bool>> _typingGroups = {};
  StreamSubscription? _msgSub;
  StreamSubscription? _typingSub;
  StreamSubscription? _onlineSub;

  @override
  void initState() {
    super.initState();
    _load();
    AppState.instance.chatList.addListener(_onChatList);
    _msgSub = SocketService.instance.messageStream.listen(_onMessage);
    _typingSub = SocketService.instance.typingStream.listen(_onTyping);
    // ✅ FIX: listen online status peer (untuk C1/C2 + dot hijau)
    _onlineSub = SocketService.instance.onlineStream.listen((d) {
      final user = (d['user'] ?? d['username'] ?? '').toString();
      final status = (d['status'] ?? '').toString();
      if (user.isEmpty) return;
      final online = status == 'online' || d['online'] == true;
      AppState.instance.updatePeerOnline(user, online);
      if (mounted) setState(() {});
    });
    NotificationService.instance.pendingOpenChat.addListener(_onNotifOpen);
  }

  @override
  void dispose() {
    AppState.instance.chatList.removeListener(_onChatList);
    _msgSub?.cancel(); _typingSub?.cancel(); _onlineSub?.cancel();
    NotificationService.instance.pendingOpenChat.removeListener(_onNotifOpen);
    super.dispose();
  }

  void _onNotifOpen() {
    final chat = NotificationService.instance.pendingOpenChat.value;
    if (chat.isEmpty) return;
    NotificationService.instance.pendingOpenChat.value = '';
    _openChatId(chat);
  }

  void _onChatList() {
    if (!mounted) return;
    final raw = AppState.instance.chatList.value;
    setState(() => _items = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList());
  }

  void _onMessage(Map<String, dynamic> d) {
    final myUser = AppState.instance.loggedUser.value;
    final from = (d['from'] ?? '').toString();
    final isGroup = d['isGroup'] == true;
    final isChannel = d['isChannel'] == true;

    if (from != myUser) {
      final partner = isChannel ? 'channel' : (isGroup ? d['to'].toString() : from);
      AppState.instance.setLocalLastMsg(
        partner: partner, isGroup: isGroup, isChannel: isChannel, msg: d,
      );
    }

    _load();
    if (from == myUser) return;
    final openId = AppState.instance.openChatId.value;
    final partner = isChannel ? 'channel' : (isGroup ? d['to'].toString() : from);
    final cid = isChannel ? 'channel' : (isGroup ? 'grp_$partner' : _sortCid(myUser, partner));
    // ✅ FIX: kalau chat sedang dibuka, jangan notif
    if (openId == cid) return;
    final t = (d['msgType'] ?? 'text').toString();
    final body = t == 'file' ? '📎 ${d['file']?['name'] ?? 'File'}'
      : t == 'voice' ? '🎤 Pesan suara' : (d['text'] ?? '').toString();
    // ✅ FIX: panggil showChatNotification (yang akan cek permission dulu)
    NotificationService.instance.showChatNotification(
      chatId: cid, from: from, fromDisplay: (d['fromName'] ?? from).toString(),
      body: body, isGroup: isGroup, isChannel: isChannel);
  }

  void _onTyping(Map<String, dynamic> d) {
    final from = (d['from'] ?? '').toString();
    final isGroup = d['isGroup'] == true;
    final isTyping = d['isTyping'] == true;
    if (isGroup) {
      final gid = (d['groupId'] ?? '').toString();
      _typingGroups[gid] ??= {};
      if (isTyping) {
        _typingGroups[gid]![from] = true;
        Timer(const Duration(seconds: 4), () {
          if (!mounted) return; _typingGroups[gid]?.remove(from); setState(() {});
        });
      } else _typingGroups[gid]?.remove(from);
    } else {
      if (isTyping) {
        _typingPeers[from] = true;
        Timer(const Duration(seconds: 4), () {
          if (!mounted) return; _typingPeers.remove(from); setState(() {});
        });
      } else _typingPeers.remove(from);
    }
    setState(() {});
  }

  Future<void> _load() async {
    final me = AppState.instance.loggedUser.value;
    if (me.isEmpty) return;
    try {
      final list = await ApiService.chatList(me);
      if (!mounted) return;
      AppState.instance.applyServerChatList(list);
    } catch (_) {}
  }

  String _sortCid(String a, String b) { final p = [a, b]..sort(); return p.join('_'); }

  void _openChatId(String cid) {
    if (cid == 'channel') {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => const ChatScreen(partner: 'channel', isGroup: false, isChannel: true)));
      return;
    }
    final isGroup = cid.startsWith('grp_');
    final partner = isGroup ? cid.substring(4)
      : cid.split('_').firstWhere((x) => x != AppState.instance.loggedUser.value, orElse: () => cid);
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ChatScreen(partner: partner, isGroup: isGroup)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          ValueListenableBuilder<String>(
            valueListenable: AppState.instance.displayName,
            builder: (_, dn, __) => ValueListenableBuilder<String?>(
              valueListenable: AppState.instance.avatar,
              builder: (_, av, __) => AppAvatar(
                name: dn.isEmpty ? AppState.instance.loggedUser.value : dn,
                url: av, size: 34))),
          const SizedBox(width: 10),
          const Text('NexChat', style: TextStyle(fontWeight: FontWeight.w600)),
        ]),
        actions: [
          const ThemeButton(),
          IconButton(icon: const Icon(Icons.search), onPressed: _openSearch),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'new_group') _openCreateGroupDialog();
              else if (v == 'join_group') _openJoinGroupDialog();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'new_group', child: Row(children: [
                Icon(Icons.group_add, size: 20), SizedBox(width: 10), Text('Buat Grup Baru'),
              ])),
              const PopupMenuItem(value: 'join_group', child: Row(children: [
                Icon(Icons.login, size: 20), SizedBox(width: 10), Text('Join Grup via Kode'),
              ])),
            ],
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _items.isEmpty
          ? ListView(children: const [SizedBox(height: 100),
              Center(child: Text('Belum ada obrolan', style: TextStyle(color: Colors.grey)))])
          : ListView.separated(
              itemCount: _items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) => _tile(_items[i]))),
    );
  }

  Widget _tile(Map<String, dynamic> c) {
    final isChannel = c['isChannel'] == true;
    final isGroup = c['isGroup'] == true;
    final partner = (c['partner'] ?? '').toString();
    final name = (c['name'] ?? (isGroup ? 'Grup' : partner)).toString();
    final avatarUrl = c['avatar'] as String?;
    final unread = (c['unread'] ?? 0) as int;
    final last = c['lastMsg'] as Map<String, dynamic>?;
    final isOnline = c['isOnline'] == true || AppState.instance.isPeerOnline(partner);
    final typing = isChannel ? false
      : isGroup ? (_typingGroups[partner]?.isNotEmpty ?? false)
      : _typingPeers.containsKey(partner);
    final myUser = AppState.instance.loggedUser.value;
    final lastIsMe = last != null && (last['from'] ?? '').toString() == myUser;
    String preview;
    if (typing) preview = 'mengetik...';
    else if (last == null) preview = isGroup ? 'Grup baru dibuat'
      : (isChannel ? 'Channel resmi NexChat' : 'Belum ada pesan');
    else if (last['deletedForEveryone'] == true) preview = 'Pesan dihapus';
    else {
      final t = (last['msgType'] ?? 'text').toString();
      String body;
      if (t == 'file') body = '📎 ${last['file']?['name'] ?? 'File'}';
      else if (t == 'voice') body = '🎤 Pesan suara';
      else body = (last['text'] ?? '').toString();
      preview = lastIsMe ? 'Anda: $body' : body;
    }
    final time = last == null ? (c['createdAt'] != null ? 'Baru' : '')
      : _formatTime(last['timestamp']);
    return ListTile(
      onTap: () {
        if (isChannel) {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => const ChatScreen(partner: 'channel', isGroup: false, isChannel: true)));
        } else {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => ChatScreen(partner: partner, isGroup: isGroup)));
        }
      },
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      leading: Stack(children: [
        AppAvatar(name: name, url: avatarUrl, size: 52, isChannel: isChannel),
        if (isOnline && !isGroup && !isChannel)
          Positioned(right: 2, bottom: 2,
            child: Container(width: 12, height: 12,
              decoration: BoxDecoration(color: const Color(0xFF00E5A0), shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2)))),
      ]),
      title: Row(children: [
        Flexible(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
        if (c['isDev'] == true) ...[
          const SizedBox(width: 4),
          const Icon(Icons.verified, size: 15, color: Color(0xFF53BDEB)),
        ],
        if (isGroup) ...[
          const SizedBox(width: 6),
          Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: Colors.grey.shade800, borderRadius: BorderRadius.circular(4)),
            child: const Text('Grup', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600))),
        ],
      ]),
      subtitle: Text(preview, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: TextStyle(color: typing ? const Color(0xFF00A884) : Colors.grey.shade500,
          fontStyle: typing ? FontStyle.italic : FontStyle.normal)),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(time, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        const SizedBox(height: 4),
        if (unread > 0) Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: const BoxDecoration(color: Color(0xFF00A884), shape: BoxShape.circle),
          constraints: const BoxConstraints(minWidth: 20),
          child: Text(unread > 99 ? '99+' : '$unread', textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600))),
      ]));
  }

  String _formatTime(dynamic ts) {
    if (ts == null) return '';
    if (ts is int) {
      final dt = DateTime.fromMillisecondsSinceEpoch(ts, isUtc: true).toLocal();
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    }
    final s = ts.toString();
    try {
      final dt = DateTime.parse(s);
      final local = dt.isUtc ? dt.toLocal() : dt;
      return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return s;
    }
  }

  Future<void> _openSearch() async {
    showSearch(context: context, delegate: _SearchDelegate());
  }

  Future<void> _openCreateGroupDialog() async {
    final nameC = TextEditingController();
    final userC = TextEditingController();
    final descC = TextEditingController();
    final membersC = TextEditingController();
    bool isPrivate = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: const Text('Buat Grup Baru'),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameC, decoration: const InputDecoration(labelText: 'Nama grup *')),
            TextField(controller: userC, decoration: const InputDecoration(labelText: 'Username grup * (3-20 huruf kecil)')),
            TextField(controller: descC, decoration: const InputDecoration(labelText: 'Deskripsi')),
            TextField(controller: membersC, decoration: const InputDecoration(labelText: 'Anggota (opsional, koma)')),
            SwitchListTile(
              value: isPrivate,
              onChanged: (v) => setSt(() => isPrivate = v),
              title: const Text('Grup privat'),
              contentPadding: EdgeInsets.zero,
            ),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Buat')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final name = nameC.text.trim();
    final gu = userC.text.trim().toLowerCase();
    if (name.isEmpty || gu.isEmpty) return;
    final members = membersC.text.split(',').map((e) => e.trim().replaceAll('@', '').toLowerCase()).where((e) => e.isNotEmpty).toList();
    try {
      final r = await ApiService.createGroup(
        username: AppState.instance.loggedUser.value,
        name: name, groupUsername: gu,
        members: members, description: descC.text.trim(), isPrivate: isPrivate);
      if (r['success'] == true) {
        if (!mounted) return;
        final g = r['group'];
        Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChatScreen(partner: g['id'].toString(), isGroup: true)));
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(r['msg']?.toString() ?? 'Gagal buat grup')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal: $e')));
    }
  }

  Future<void> _openJoinGroupDialog() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Join Grup via Kode'),
        content: TextField(controller: c, decoration: const InputDecoration(hintText: 'Kode undangan')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Join')),
        ],
      ),
    );
    if (ok != true) return;
    final code = c.text.trim();
    if (code.isEmpty) return;
    try {
      final r = await ApiService.joinViaLink(AppState.instance.loggedUser.value, code);
      if (r['success'] == true) {
        if (!mounted) return;
        final g = r['group'];
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Berhasil join!')));
        Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChatScreen(partner: g['id'].toString(), isGroup: true)));
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(r['msg']?.toString() ?? 'Kode tidak valid')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal: $e')));
    }
  }
}

class _SearchDelegate extends SearchDelegate {
  @override
  List<Widget>? buildActions(BuildContext context) => [
    IconButton(icon: const Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
    icon: const Icon(Icons.arrow_back), onPressed: () => close(context, null));

  @override
  Widget buildResults(BuildContext context) => _buildList(context);

  @override
  Widget buildSuggestions(BuildContext context) => _buildList(context);

  Widget _buildList(BuildContext context) {
    if (query.trim().isEmpty) return const Center(child: Text('Cari username, nama, atau grup'));
    return FutureBuilder<Map<String, dynamic>>(
      future: ApiService.search(query.trim(), exclude: AppState.instance.loggedUser.value),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final results = (snap.data!['results'] as List?) ?? [];
        if (results.isEmpty) return const Center(child: Text('Tidak ada hasil'));
        return ListView.builder(itemCount: results.length,
          itemBuilder: (_, i) {
            final r = Map<String, dynamic>.from(results[i] as Map);
            final isUser = r['type'] == 'user';
            final name = isUser
              ? (r['displayName'] != null && (r['displayName'] as String).isNotEmpty
                  ? r['displayName'] : r['username'])
              : r['name'];
            return ListTile(
              leading: AppAvatar(name: name.toString(), url: r['avatar'] as String?, size: 44),
              title: Text(name.toString()),
              subtitle: Text(isUser ? '@${r['username']}' : '@${r['username']} · ${r['memberCount']} anggota'),
              onTap: () async {
                if (isUser) {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ChatScreen(partner: r['username'].toString(), isGroup: false)));
                } else if (r['isMember'] == true) {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ChatScreen(partner: r['id'].toString(), isGroup: true)));
                } else {
                  try {
                    final res = await ApiService.joinPublicGroup(
                      AppState.instance.loggedUser.value, r['username'].toString());
                    if (res['success'] == true) {
                      if (!context.mounted) return;
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                        builder: (_) => ChatScreen(partner: r['id'].toString(), isGroup: true)));
                    }
                  } catch (_) {}
                }
              });
          });
      });
  }
}
