import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../app_state.dart';
import '../config.dart';
import '../services/api_service.dart';
import '../widgets/avatar.dart';
import '../widgets/theme_button.dart';

class StatusTab extends StatefulWidget {
  const StatusTab({super.key});
  @override
  State<StatusTab> createState() => _StatusTabState();
}

class _StatusTabState extends State<StatusTab> {
  List<Map<String, dynamic>> _mine = [];
  List<Map<String, dynamic>> _others = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final u = AppState.instance.loggedUser.value;
    if (u.isEmpty) return;
    try {
      final m = await ApiService.myStatuses(u);
      final o = await ApiService.statusList(u);
      if (!mounted) return;
      setState(() {
        _mine = ((m['statuses'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
        _others = ((o['statuses'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Status', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: const [ThemeButton()]),
      body: RefreshIndicator(onRefresh: _load, child: ListView(children: [
        const Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text('Status saya', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey))),
        ListTile(
          leading: Stack(children: [
            AppAvatar(
              name: AppState.instance.displayName.value.isEmpty
                ? AppState.instance.loggedUser.value : AppState.instance.displayName.value,
              url: AppState.instance.avatar.value, size: 52),
            Positioned(right: 0, bottom: 0,
              child: Container(width: 20, height: 20,
                decoration: BoxDecoration(color: const Color(0xFF00A884),
                  shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                child: const Icon(Icons.add, size: 12, color: Colors.white))),
          ]),
          title: const Text('Status saya'),
          subtitle: Text(_mine.isEmpty ? 'Ketuk untuk tambah' : '${_mine.length} pembaruan'),
          onTap: _mine.isEmpty ? _openCreateMenu : _viewMine,
        ),
        if (_others.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text('Terbaru', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey))),
          ..._others.map((s) => _otherStatusTile(s)),
        ] else Padding(padding: const EdgeInsets.all(40),
          child: Center(child: Text('Belum ada status dari orang lain',
            style: TextStyle(color: Colors.grey)))),
      ])),
      floatingActionButton: FloatingActionButton(
        onPressed: _openCreateMenu, backgroundColor: const Color(0xFF00A884),
        child: const Icon(Icons.add, color: Colors.white)));
  }

  Widget _otherStatusTile(Map<String, dynamic> s) {
    final name = (s['displayName'] ?? s['owner']).toString();
    final viewed = s['allViewed'] == true;
    return ListTile(
      leading: Container(padding: const EdgeInsets.all(2.5),
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: viewed
            ? LinearGradient(colors: [Colors.grey.shade400, Colors.grey.shade400])
            : const LinearGradient(colors: [Color(0xFF00A884), Color(0xFF0088CC)])),
        child: Container(padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(color: Theme.of(context).scaffoldBackgroundColor, shape: BoxShape.circle),
          child: AppAvatar(name: name, url: s['avatar'] as String?, size: 48))),
      title: Text(name),
      subtitle: Text('${s['count']} pembaruan'),
      onTap: () => _viewStatus(s['owner'].toString()));
  }

  Future<void> _openCreateMenu() async {
    final choice = await showModalBottomSheet<String>(
      context: context, builder: (_) => SafeArea(child: Column(
        mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        const Padding(padding: EdgeInsets.symmetric(vertical: 12),
          child: Text('Tambah Status', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.text_fields, color: Color(0xFF7F66FF)),
          title: const Text('Tulis status'), subtitle: const Text('Bagikan tulisan'),
          onTap: () => Navigator.pop(context, 'text')),
        ListTile(leading: const Icon(Icons.image, color: Color(0xFF00A884)),
          title: const Text('Gambar'), subtitle: const Text('Pilih foto dari galeri'),
          onTap: () => Navigator.pop(context, 'image')),
        ListTile(leading: const Icon(Icons.videocam, color: Color(0xFFE542A3)),
          title: const Text('Video'), subtitle: const Text('Pilih video dari galeri'),
          onTap: () => Navigator.pop(context, 'video')),
        const SizedBox(height: 8),
      ])));
    if (choice == null) return;
    if (choice == 'text') await _createTextStatus();
    else if (choice == 'image') await _createMediaStatus('image');
    else if (choice == 'video') await _createMediaStatus('video');
  }

  Future<void> _createTextStatus() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Tulis status'),
      content: TextField(controller: c, maxLines: 5, maxLength: 500, autofocus: true,
        decoration: const InputDecoration(hintText: 'Apa yang kamu pikirkan...', border: OutlineInputBorder())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Bagikan')),
      ]));
    if (ok != true) return;
    final text = c.text.trim();
    if (text.isEmpty) return;
    _showLoading();
    try {
      await ApiService.createStatus(username: AppState.instance.loggedUser.value, text: text);
    } catch (_) {}
    _hideLoading();
    _load();
  }

  Future<void> _createMediaStatus(String kind) async {
    final picker = ImagePicker();
    XFile? file;
    try {
      if (kind == 'image') {
        file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1280);
      } else {
        file = await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 1));
      }
    } catch (_) {}
    if (file == null) return;

    final caption = TextEditingController();
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Tambah keterangan'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        if (kind == 'image')
          ClipRRect(borderRadius: BorderRadius.circular(8),
            child: Image.file(File(file!.path), height: 160, fit: BoxFit.cover))
        else Container(height: 100,
          decoration: BoxDecoration(color: Colors.grey.shade800, borderRadius: BorderRadius.circular(8)),
          child: const Center(child: Icon(Icons.videocam, size: 48, color: Colors.grey))),
        const SizedBox(height: 12),
        TextField(controller: caption, maxLines: 3, maxLength: 300,
          decoration: const InputDecoration(hintText: 'Keterangan (opsional)', border: OutlineInputBorder())),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Bagikan')),
      ]));
    if (ok != true) return;

    _showLoading();
    try {
      final bytes = await file!.readAsBytes();
      final uri = Uri.parse('${AppConfig.backendUrl}/api/upload');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: file.name));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      final r = jsonDecode(body) as Map<String, dynamic>;
      if (r['success'] != true) {
        _hideLoading();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal upload')));
        return;
      }
      final url = (r['file']['url'] ?? '').toString();
      await ApiService.createStatus(
        username: AppState.instance.loggedUser.value,
        text: caption.text.trim(),
        image: kind == 'image' ? url : null,
        video: kind == 'video' ? url : null);
      _hideLoading();
      _load();
    } catch (e) {
      _hideLoading();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal: $e')));
    }
  }

  void _showLoading() {
    showDialog(context: context, barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()));
  }

  void _hideLoading() {
    if (mounted) Navigator.of(context, rootNavigator: true).pop();
  }

  Future<void> _viewMine() async {
    final r = await ApiService.myStatuses(AppState.instance.loggedUser.value);
    final arr = (r['statuses'] as List?) ?? [];
    if (arr.isEmpty || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => StatusViewerScreen(
      owner: AppState.instance.loggedUser.value,
      displayName: AppState.instance.displayName.value.isEmpty
        ? AppState.instance.loggedUser.value : AppState.instance.displayName.value,
      avatar: AppState.instance.avatar.value,
      statuses: arr.map((e) => Map<String, dynamic>.from(e as Map)).toList(),
      isMine: true, onDeleted: _load)));
  }

  Future<void> _viewStatus(String owner) async {
    final r = await ApiService.viewStatus(owner, AppState.instance.loggedUser.value);
    final arr = (r['statuses'] as List?) ?? [];
    if (arr.isEmpty || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => StatusViewerScreen(
      owner: owner,
      displayName: (r['displayName'] ?? owner).toString(),
      avatar: r['avatar'] as String?,
      statuses: arr.map((e) => Map<String, dynamic>.from(e as Map)).toList(),
      isMine: false, onDeleted: _load)));
  }
}

class StatusViewerScreen extends StatefulWidget {
  final String owner;
  final String displayName;
  final String? avatar;
  final List<Map<String, dynamic>> statuses;
  final bool isMine;
  final VoidCallback onDeleted;
  const StatusViewerScreen({super.key, required this.owner, required this.displayName,
    required this.avatar, required this.statuses, required this.isMine, required this.onDeleted});
  @override
  State<StatusViewerScreen> createState() => _StatusViewerScreenState();
}

class _StatusViewerScreenState extends State<StatusViewerScreen>
    with SingleTickerProviderStateMixin {
  int _idx = 0;
  late AnimationController _progress;
  VideoPlayerController? _video;
  bool _paused = false;

  @override
  void initState() {
    super.initState();
    _progress = AnimationController(vsync: this);
    _progress.addStatusListener((s) {
      if (s == AnimationStatus.completed && !_paused) _next();
    });
    _startCurrent();
  }

  @override
  void dispose() {
    _progress.dispose();
    _video?.dispose();
    super.dispose();
  }

  Future<void> _startCurrent() async {
    _progress.stop();
    _progress.value = 0;
    await _video?.dispose();
    _video = null;
    _paused = false;
    if (_idx >= widget.statuses.length) return;
    final s = widget.statuses[_idx];
    final videoUrl = s['video'] as String?;
    if (videoUrl != null && videoUrl.isNotEmpty) {
      try {
        final url = videoUrl.startsWith('http') || videoUrl.startsWith('data:')
          ? videoUrl : '${AppConfig.backendUrl}$videoUrl';
        _video = VideoPlayerController.networkUrl(Uri.parse(url));
        await _video!.initialize();
        await _video!.play();
        _video!.addListener(_onVideoTick);
        if (mounted) setState(() {});
      } catch (_) {
        _progress.duration = const Duration(seconds: 4);
        _progress.forward(from: 0);
      }
    } else {
      final textLen = (s['text'] ?? '').toString().length;
      _progress.duration = Duration(seconds: textLen > 80 ? 6 : 4);
      _progress.forward(from: 0);
    }
  }

  void _onVideoTick() {
    if (!mounted || _video == null || _paused) return;
    if (!_video!.value.isInitialized) return;
    final total = _video!.value.duration.inMilliseconds;
    final cur = _video!.value.position.inMilliseconds;
    if (total > 0) _progress.value = cur / total;
    if (_video!.value.position >= _video!.value.duration &&
        _video!.value.duration > Duration.zero) {
      _next();
    }
  }

  void _next() {
    if (_idx < widget.statuses.length - 1) {
      setState(() => _idx++);
      _startCurrent();
    } else {
      Navigator.of(context).pop();
    }
  }

  void _prev() {
    if (_idx > 0) {
      setState(() => _idx--);
      _startCurrent();
    } else {
      _progress.forward(from: 0);
    }
  }

  void _pause() {
    if (_paused) return;
    _paused = true;
    _progress.stop();
    _video?.pause();
    if (mounted) setState(() {});
  }

  void _resume() {
    if (!_paused) return;
    _paused = false;
    if (_video != null) { _video!.play(); }
    else { _progress.forward(); }
    if (mounted) setState(() {});
  }

  Future<void> _deleteCurrent() async {
    final s = widget.statuses[_idx];
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Hapus status?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true),
          child: const Text('Hapus', style: TextStyle(color: Colors.red))),
      ]));
    if (ok != true) return;
    await ApiService.deleteStatus(widget.owner, s['id'].toString());
    widget.onDeleted();
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.statuses.isEmpty || _idx >= widget.statuses.length) {
      return const SizedBox.shrink();
    }
    final s = widget.statuses[_idx];
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          if (_paused) return;
          if (d.globalPosition.dx < w * 0.33) _prev();
          else _next();
        },
        onLongPressStart: (_) => _pause(),
        onLongPressEnd: (_) => _resume(),
        child: SafeArea(child: Stack(children: [
          Positioned.fill(child: _buildContent(s)),
          Positioned(top: 8, left: 8, right: 8,
            child: Column(children: [
              _buildProgressBars(),
              const SizedBox(height: 10),
              _buildHeader(s),
            ])),
        ])),
      ),
    );
  }

  Widget _buildProgressBars() {
    return Row(children: List.generate(widget.statuses.length, (i) {
      return Expanded(child: Container(
        height: 3, margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
        child: i < _idx
          ? Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))
          : i == _idx
            ? AnimatedBuilder(animation: _progress,
                builder: (_, __) => FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: _progress.value.clamp(0.0, 1.0),
                  child: Container(decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(2)))))
            : const SizedBox.shrink()));
    }));
  }

  Widget _buildHeader(Map<String, dynamic> s) {
    final createdAt = (s['createdAt'] is int)
      ? DateTime.fromMillisecondsSinceEpoch(s['createdAt'] as int)
      : DateTime.now();
    final timeStr = '${createdAt.hour.toString().padLeft(2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}';
    return Row(children: [
      AppAvatar(name: widget.displayName, url: widget.avatar, size: 38),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.displayName, style: const TextStyle(color: Colors.white,
          fontWeight: FontWeight.w600, fontSize: 15)),
        Text(timeStr, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ])),
      if (_paused) const Padding(padding: EdgeInsets.only(right: 6),
        child: Icon(Icons.pause_circle, color: Colors.white70, size: 22)),
      if (widget.isMine) IconButton(
        icon: const Icon(Icons.delete_outline, color: Colors.white),
        onPressed: _deleteCurrent),
      IconButton(icon: const Icon(Icons.close, color: Colors.white),
        onPressed: () => Navigator.of(context).pop()),
    ]);
  }

  Widget _buildContent(Map<String, dynamic> s) {
    final text = (s['text'] ?? '').toString();
    final imageUrl = s['image'] as String?;
    final videoUrl = s['video'] as String?;

    if (videoUrl != null && videoUrl.isNotEmpty && _video != null && _video!.value.isInitialized) {
      return Stack(fit: StackFit.expand, children: [
        FittedBox(fit: BoxFit.contain,
          child: SizedBox(width: _video!.value.size.width, height: _video!.value.size.height,
            child: VideoPlayer(_video!))),
        if (text.isNotEmpty) Positioned(left: 16, right: 16, bottom: 32,
          child: Container(padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(10)),
            child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center))),
      ]);
    }

    if (imageUrl != null && imageUrl.isNotEmpty) {
      final url = imageUrl.startsWith('http') || imageUrl.startsWith('data:')
        ? imageUrl : '${AppConfig.backendUrl}$imageUrl';
      return Stack(fit: StackFit.expand, children: [
        Center(child: Image.network(url, fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Center(
            child: Icon(Icons.broken_image, color: Colors.white54, size: 64)))),
        if (text.isNotEmpty) Positioned(left: 16, right: 16, bottom: 32,
          child: Container(padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(10)),
            child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center))),
      ]);
    }

    return Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Text(text.isEmpty ? '(kosong)' : text,
        style: const TextStyle(color: Colors.white, fontSize: 22,
          height: 1.5, fontWeight: FontWeight.w500),
        textAlign: TextAlign.center)));
  }
}
