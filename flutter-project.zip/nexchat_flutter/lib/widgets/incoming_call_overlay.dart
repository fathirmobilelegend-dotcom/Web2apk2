import 'package:flutter/material.dart';
import '../services/call_service.dart';
import '../services/socket_service.dart';
import '../services/notification_service.dart';
import 'avatar.dart';
import '../screens/call_screen.dart';

class IncomingCallOverlay extends StatefulWidget {
  const IncomingCallOverlay({super.key});
  @override
  State<IncomingCallOverlay> createState() => _IncomingCallOverlayState();
}

class _IncomingCallOverlayState extends State<IncomingCallOverlay> {
  @override
  void initState() {
    super.initState();
    SocketService.instance.callOfferStream.listen((data) {
      CallService.instance.handleIncomingOffer(data);
      NotificationService.instance.showIncomingCallNotification(
        from: (data['from'] ?? '').toString(),
        fromDisplay: (data['fromName'] ?? data['from'] ?? '').toString(),
        callType: (data['callType'] ?? 'audio').toString());
    });
    SocketService.instance.callAnswerStream.listen(CallService.instance.handleAnswer);
    SocketService.instance.callIceStream.listen(CallService.instance.handleIce);
    SocketService.instance.callEndStream.listen((d) {
      CallService.instance.handleRemoteEnd(d);
      NotificationService.instance.cancelCallNotification();
    });
    SocketService.instance.callBusyStream.listen((_) => CallService.instance.handleRemoteEnd({}));
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<CallState>(
      valueListenable: CallService.instance.state,
      builder: (_, state, __) {
        if (state != CallState.incoming) return const SizedBox.shrink();
        return _buildPopup(context);
      },
    );
  }

  Widget _buildPopup(BuildContext context) {
    return Material(
      color: Colors.black54,
      child: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Card(
              elevation: 16,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              child: ValueListenableBuilder<String>(
                valueListenable: CallService.instance.peerName,
                builder: (_, name, __) => ValueListenableBuilder<String?>(
                  valueListenable: CallService.instance.peerAvatar,
                  builder: (_, avatar, __) => Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      AppAvatar(name: name, url: avatar, size: 52),
                      const SizedBox(width: 12),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          ValueListenableBuilder<String>(
                            valueListenable: CallService.instance.callType,
                            builder: (_, t, __) => Text(
                              t == 'video' ? 'Panggilan video masuk' : 'Panggilan suara masuk',
                              style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          ),
                        ],
                      )),
                      IconButton(
                        onPressed: () {
                          NotificationService.instance.cancelCallNotification();
                          CallService.instance.rejectIncoming();
                        },
                        icon: const Icon(Icons.call_end, color: Colors.red),
                        style: IconButton.styleFrom(backgroundColor: Colors.red.shade50),
                      ),
                      const SizedBox(width: 6),
                      IconButton(
                        onPressed: () async {
                          NotificationService.instance.cancelCallNotification();
                          await CallService.instance.acceptIncoming();
                          if (!context.mounted) return;
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CallScreen()));
                        },
                        icon: const Icon(Icons.call, color: Colors.white),
                        style: IconButton.styleFrom(backgroundColor: const Color(0xFF00A884)),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
