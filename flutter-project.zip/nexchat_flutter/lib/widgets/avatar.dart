import 'dart:convert';
import 'package:flutter/material.dart';
import '../config.dart';

class AppAvatar extends StatelessWidget {
  final String name;
  final String? url;
  final double size;
  final bool isChannel;

  const AppAvatar({super.key, required this.name, this.url, this.size = 48, this.isChannel = false});

  @override
  Widget build(BuildContext context) {
    if (isChannel) {
      return _wrap(
        const LinearGradient(colors: [Color(0xFF00A884), Color(0xFF0088CC)]),
        const Icon(Icons.campaign, color: Colors.white),
      );
    }
    final raw = (url ?? '').trim();
    if (raw.isNotEmpty) return ClipOval(child: _buildImage(raw));
    return _fallback();
  }

  Widget _buildImage(String raw) {
    if (raw.startsWith('data:')) {
      try {
        final b64 = raw.split(',').last;
        final bytes = base64Decode(b64);
        return Image.memory(bytes, width: size, height: size, fit: BoxFit.cover,
          gaplessPlayback: true,
          errorBuilder: (_, __, ___) => _fallback());
      } catch (_) { return _fallback(); }
    }
    final fullUrl = raw.startsWith('http') ? raw : '${AppConfig.backendUrl}$raw';
    return Image.network(fullUrl, width: size, height: size, fit: BoxFit.cover,
      gaplessPlayback: true,
      errorBuilder: (_, __, ___) => _fallback());
  }

  Widget _fallback() {
    final initial = _initialOf(name);
    final color = _colorFor(name);
    return _wrap(
      LinearGradient(colors: [color, color.withOpacity(.75)]),
      Text(initial, style: TextStyle(
        color: Colors.white, fontWeight: FontWeight.w600, fontSize: size * 0.42)),
    );
  }

  Widget _wrap(Gradient g, Widget child) => Container(
    width: size, height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, gradient: g),
    alignment: Alignment.center, child: child,
  );

  static String _initialOf(String s) {
    final t = s.trim();
    if (t.isEmpty) return '?';
    return t[0].toUpperCase();
  }

  static Color _colorFor(String name) {
    const colors = [
      Color(0xFF00A884), Color(0xFF0088CC), Color(0xFF7F66FF),
      Color(0xFFFF7A45), Color(0xFFE542A3), Color(0xFFF4B400),
      Color(0xFF00BCD4), Color(0xFF8BC34A), Color(0xFFF06292), Color(0xFF5C6BC0),
    ];
    return colors[name.hashCode.abs() % colors.length];
  }
}
