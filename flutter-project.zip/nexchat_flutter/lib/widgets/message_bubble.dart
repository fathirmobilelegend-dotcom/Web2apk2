import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import '../app_state.dart';
import '../config.dart';

String _fmtTime(dynamic ts) {
  if (ts == null) return '';
  if (ts is int) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ts, isUtc: true).toLocal();
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
  final s = ts.toString();
  try {
    final dt = DateTime.parse(s);
    final local = dt.isUtc ? dt.toLocal() : dt;
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  } catch (_) {
    return s;
  }
}

class MessageBubble extends StatelessWidget {
  final Map<String, dynamic> msg;
  final bool isGroup;
  final bool isChannel;
  final bool peerOnline;
  final void Function(Map<String, dynamic>) onReply;
  final VoidCallback onLongPress;
  final void Function(String url, String filename) onDownload;
  final void Function(Map<String, dynamic>)? onJumpTo;

  const MessageBubble({
    super.key,
    required this.msg,
    required this.isGroup,
    required this.isChannel,
    this.peerOnline = false,
    required this.onReply,
    required this.onLongPress,
    required this.onDownload,
    this.onJumpTo,
  });

  @override
  Widget build(BuildContext context) {
    final myUser = AppState.instance.loggedUser.value;
    final isMe = (msg['from'] ?? '').toString() == myUser;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final deleted = msg['deletedForEveryone'] == true;

    final bubbleColor = isMe
      ? (isDark ? const Color(0xFF005C4B) : const Color(0xFFDCF8C6))
      : (isDark ? const Color(0xFF202C33) : Colors.white);
    final textColor = isDark ? Colors.white : Colors.black87;
    final subColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Container(
          margin: EdgeInsets.only(
            left: isMe ? 50 : 4, right: isMe ? 4 : 50, top: 2, bottom: 2),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(12),
              topRight: const Radius.circular(12),
              bottomLeft: Radius.circular(isMe ? 12 : 2),
              bottomRight: Radius.circular(isMe ? 2 : 12))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isMe && isGroup && msg['fromName'] != null)
                Padding(padding: const EdgeInsets.only(bottom: 2),
                  child: Text(msg['fromName'].toString(),
                    style: const TextStyle(color: Color(0xFF00A884),
                      fontSize: 12, fontWeight: FontWeight.w600))),
              if (msg['forwarded'] == true)
                Padding(padding: const EdgeInsets.only(bottom: 2),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.forward, size: 11, color: subColor),
                    const SizedBox(width: 4),
                    Text('Diteruskan', style: TextStyle(fontSize: 11,
                      fontStyle: FontStyle.italic, color: subColor))])),
              if (msg['replyTo'] != null) _buildReplyPreview(isDark, subColor),
              if (deleted)
                Padding(padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.block, size: 14, color: subColor),
                    const SizedBox(width: 4),
                    Text('Pesan telah dihapus',
                      style: TextStyle(fontStyle: FontStyle.italic, color: subColor))]))
              else _buildContent(textColor),
              const SizedBox(height: 2),
              Row(mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end, children: [
                Text(_fmtTime(msg['timestamp']),
                  style: TextStyle(fontSize: 10, color: subColor)),
                if (isMe) ...[
                  const SizedBox(width: 4),
                  _statusIcon(subColor)]])])))); 
  }

  // ✅ FIX: C1/C2 logic
  // - readBy non-empty → biru (dibaca)
  // - deliveredTo non-empty → C2 (✓✓)
  // - peerOnline → C2 (✓✓) fallback kalau server gak push delivered
  // - else → C1 (✓)
  Widget _statusIcon(Color c) {
    final readBy = (msg['readBy'] as List?) ?? [];
    final deliveredTo = (msg['deliveredTo'] as List?) ?? [];
    if (readBy.isNotEmpty) {
      return const Icon(Icons.done_all, size: 14, color: Color(0xFF53BDEB));
    }
    if (deliveredTo.isNotEmpty || peerOnline) {
      return Icon(Icons.done_all, size: 14, color: c);
    }
    return Icon(Icons.done, size: 14, color: c);
  }

  Widget _buildReplyPreview(bool isDark, Color subColor) {
    final r = Map<String, dynamic>.from(msg['replyTo'] as Map);
    final from = (r['from'] ?? '').toString() == AppState.instance.loggedUser.value
        ? 'Anda' : (r['fromName'] ?? r['from'] ?? '').toString();
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: isDark ? Colors.black26 : Colors.black12,
        borderRadius: BorderRadius.circular(6),
        border: const Border(left: BorderSide(color: Color(0xFF00A884), width: 3))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min, children: [
        Text(from, style: const TextStyle(color: Color(0xFF00A884),
          fontSize: 11, fontWeight: FontWeight.w600)),
        Text(_previewOf(r), maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12))]));
  }

  String _previewOf(Map<String, dynamic> m) {
    final t = (m['msgType'] ?? 'text').toString();
    if (t == 'file') return '📎 ${m['file']?['name'] ?? 'File'}';
    if (t == 'voice') return '🎤 Pesan suara';
    return (m['text'] ?? '').toString();
  }

  Widget _buildContent(Color textColor) {
    final type = (msg['msgType'] ?? 'text').toString();
    final text = (msg['text'] ?? '').toString();

    if (type == 'voice') return _VoiceBubble(msg: msg, textColor: textColor);

    if (type == 'file' && msg['file'] != null) {
      final file = Map<String, dynamic>.from(msg['file'] as Map);
      final name = (file['name'] ?? 'File').toString();
      final url  = (file['url'] ?? '').toString();
      final size = (file['size'] ?? 0) as int;
      if (_isImage(name) && url.isNotEmpty) {
        final fullUrl = url.startsWith('http') || url.startsWith('data:')
          ? url : '${AppConfig.backendUrl}$url';
        return Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min, children: [
          ClipRRect(borderRadius: BorderRadius.circular(8),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 240, maxWidth: 260),
              child: Image.network(fullUrl, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _fileTile(name, size, textColor)))),
          if (text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6),
            child: Text(text, style: TextStyle(color: textColor, fontSize: 15)))]); 
      }
      return Column(crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min, children: [
        InkWell(onTap: () => onDownload(url, name),
          child: _fileTile(name, size, textColor)),
        if (text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6),
          child: Text(text, style: TextStyle(color: textColor, fontSize: 15)))]); 
    }
    return Text(text, style: TextStyle(color: textColor, fontSize: 15, height: 1.35));
  }

  Widget _fileTile(String name, int size, Color textColor) => Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(color: Colors.black12,
      borderRadius: BorderRadius.circular(6)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.insert_drive_file, color: Color(0xFF00A884), size: 30),
      const SizedBox(width: 10),
      Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min, children: [
        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: textColor)),
        const SizedBox(height: 2),
        Text(_humanSize(size), style: const TextStyle(fontSize: 11, color: Colors.grey))]))])); 

  static String _humanSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(1)} GB';
  }

  static bool _isImage(String n) {
    final l = n.toLowerCase();
    return l.endsWith('.jpg') || l.endsWith('.jpeg') || l.endsWith('.png') ||
           l.endsWith('.gif') || l.endsWith('.webp');
  }
}

class _VoiceBubble extends StatefulWidget {
  final Map<String, dynamic> msg;
  final Color textColor;
  const _VoiceBubble({required this.msg, required this.textColor});
  @override
  State<_VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<_VoiceBubble> {
  final _player = AudioPlayer();
  bool _playing = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;
  StreamSubscription? _pSub, _dSub, _cSub;

  @override
  void initState() {
    super.initState();
    _pSub = _player.onPositionChanged.listen((p) => mounted ? setState(() => _pos = p) : null);
    _dSub = _player.onDurationChanged.listen((d) => mounted ? setState(() => _dur = d) : null);
    _cSub = _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() { _playing = false; _pos = Duration.zero; });
    });
    final secs = (widget.msg['file']?['duration'] ?? 0) as int;
    _dur = Duration(seconds: secs);
  }

  @override
  void dispose() {
    _pSub?.cancel(); _dSub?.cancel(); _cSub?.cancel();
    _player.dispose(); super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) { await _player.pause(); setState(() => _playing = false); return; }
    final file = widget.msg['file'] as Map?;
    final url = (file?['url'] ?? '').toString();
    if (url.isEmpty) return;
    final fullUrl = url.startsWith('http') || url.startsWith('data:')
      ? url : '${AppConfig.backendUrl}$url';
    try {
      if (_pos == Duration.zero || _pos >= _dur) await _player.play(UrlSource(fullUrl));
      else await _player.resume();
      setState(() => _playing = true);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final total = _dur.inSeconds > 0 ? _dur.inSeconds : 1;
    final progress = _pos.inMilliseconds / (_dur.inMilliseconds > 0 ? _dur.inMilliseconds : 1);
    final mm = (_pos.inSeconds ~/ 60).toString();
    final ss = (_pos.inSeconds % 60).toString().padLeft(2, '0');
    return Row(mainAxisSize: MainAxisSize.min, children: [
      IconButton(onPressed: _toggle, padding: EdgeInsets.zero,
        constraints: const BoxConstraints(),
        icon: Icon(_playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
          color: const Color(0xFF00A884), size: 36)),
      const SizedBox(width: 6),
      SizedBox(width: 140, child: Stack(children: [
        Container(height: 4, decoration: BoxDecoration(
          color: Colors.grey.shade400, borderRadius: BorderRadius.circular(2))),
        FractionallySizedBox(
          widthFactor: progress.clamp(0.0, 1.0),
          child: Container(height: 4, decoration: BoxDecoration(
            color: const Color(0xFF00A884), borderRadius: BorderRadius.circular(2))))])),
      const SizedBox(width: 8),
      Text(_playing ? '$mm:$ss' : '${total}s',
        style: TextStyle(fontSize: 11, color: widget.textColor))]);
  }
}
