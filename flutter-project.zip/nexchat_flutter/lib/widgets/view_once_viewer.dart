import 'dart:async';
import 'package:flutter/material.dart';
import '../config.dart';

class ViewOnceViewer extends StatefulWidget {
  final String url;
  final bool isVideo;
  final VoidCallback onClosed;
  const ViewOnceViewer({
    super.key,
    required this.url,
    required this.isVideo,
    required this.onClosed,
  });
  @override
  State<ViewOnceViewer> createState() => _ViewOnceViewerState();
}

class _ViewOnceViewerState extends State<ViewOnceViewer> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    if (widget.isVideo) {
      _timer = Timer(const Duration(seconds: 15), _close);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _close() {
    widget.onClosed();
    if (mounted) Navigator.of(context).pop();
  }

  String get _full {
    if (widget.url.startsWith('http') || widget.url.startsWith('data:')) {
      return widget.url;
    }
    return '${AppConfig.backendUrl}${widget.url}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _close,
        child: SafeArea(child: Stack(children: [
          Positioned.fill(
            child: widget.isVideo
              ? const Center(child: Icon(
                  Icons.videocam, color: Colors.white54, size: 96))
              : Image.network(_full, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Center(child: Icon(
                    Icons.broken_image, color: Colors.white54, size: 64))),
          ),
          Positioned(
            top: 8, left: 8, right: 8,
            child: Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(20)),
                child: const Row(children: [
                  Icon(Icons.looks_one, color: Colors.white, size: 16),
                  SizedBox(width: 6),
                  Text('1x lihat', style: TextStyle(color: Colors.white, fontSize: 12)),
                ]),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: _close),
            ]),
          ),
          Positioned(
            bottom: 24, left: 0, right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(20)),
                child: const Text(
                  'Foto ini hanya bisa dilihat sekali',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ),
          ),
        ])),
      ),
    );
  }
}
