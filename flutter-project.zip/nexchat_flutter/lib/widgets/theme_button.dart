import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services/api_service.dart';

class ThemeButton extends StatelessWidget {
  const ThemeButton({super.key});
  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.palette_outlined),
      tooltip: 'Ganti tema',
      onPressed: () => showThemePicker(context),
    );
  }
}

Future<void> showThemePicker(BuildContext context) async {
  const themes = [
    {'id': 'light', 'name': 'Cerah', 'color': Color(0xFF00A884)},
    {'id': 'dark', 'name': 'Gelap', 'color': Color(0xFF00A884)},
    {'id': 'blue', 'name': 'Biru', 'color': Color(0xFF1976D2)},
    {'id': 'green', 'name': 'Hijau', 'color': Color(0xFF2E7D32)},
    {'id': 'purple', 'name': 'Ungu', 'color': Color(0xFF8E24AA)},
    {'id': 'orange', 'name': 'Orange', 'color': Color(0xFFEF6C00)},
  ];
  await showDialog<void>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Pilih Tema'),
      content: ValueListenableBuilder<String>(
        valueListenable: AppState.instance.theme,
        builder: (_, current, __) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: themes.map((t) {
              final id = t['id'] as String;
              final name = t['name'] as String;
              final color = t['color'] as Color;
              final selected = id == current;
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                leading: Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: color, shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? Colors.black : Colors.grey.shade300,
                      width: selected ? 3 : 1)),
                ),
                title: Text(name),
                trailing: selected ? const Icon(Icons.check, color: Color(0xFF00A884)) : null,
                onTap: () async {
                  await AppState.instance.setTheme(id);
                  try {
                    await ApiService.updateProfile(
                      username: AppState.instance.loggedUser.value, theme: id);
                  } catch (_) {}
                  if (context.mounted) Navigator.pop(context);
                },
              );
            }).toList(),
          );
        },
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
      ],
    ),
  );
}
