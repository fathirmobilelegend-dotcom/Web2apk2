import 'dart:io';
import 'package:flutter/material.dart';

class MediaPreviewScreen extends StatefulWidget {
  final String path;
  final bool isVideo;
  final Future<void> Function(String path, String caption, bool viewOnce) onSend;
  const MediaPreviewScreen({
    super.key,
    required this.path,
    required this.isVideo,
    required this.onSend,
  });
  @override
  State<MediaPreviewScreen> createState() => _MediaPreviewScreenState();
}

class _MediaPreviewScreenState extends State<MediaPreviewScreen> {
  final _caption = TextEditingController();
  bool _viewOnce = false;
  bool _sending = false;

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await widget.onSend(widget.path, _caption.text.trim(), _viewOnce);
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() => _sending = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal mengirim')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(children: [
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 26),
                onPressed: () => Navigator.of(context).pop(),
              ),
              const Spacer(),
              if (widget.isVideo)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(12)),
                  child: const Row(children: [
                    Icon(Icons.videocam, color: Colors.white, size: 14),
                    SizedBox(width: 4),
                    Text('Video', style: TextStyle(color: Colors.white, fontSize: 12)),
                  ]),
                ),
            ]),
          ),
          Expanded(
            child: Center(
              child: widget.isVideo
                ? Container(
                    color: Colors.black,
                    child: const Center(child: Icon(
                      Icons.play_circle_outline,
                      color: Colors.white54, size: 96)))
                : InteractiveViewer(
                    child: Image.file(File(widget.path), fit: BoxFit.contain)),
            ),
          ),
          Container(
            color: Colors.black,
            padding: EdgeInsets.only(
              left: 12, right: 12, top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 10),
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              InkWell(
                onTap: () => setState(() => _viewOnce = !_viewOnce),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _viewOnce ? const Color(0xFF00A884) : Colors.white10),
                  child: Icon(
                    _viewOnce ? Icons.looks_one : Icons.looks_one_outlined,
                    color: Colors.white, size: 22),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _caption,
                  style: const TextStyle(color: Colors.white),
                  maxLines: 4, minLines: 1,
                  decoration: InputDecoration(
                    hintText: 'Tambah keterangan...',
                    hintStyle: const TextStyle(color: Colors.white54),
                    filled: true,
                    fillColor: Colors.white10,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(22),
                      borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _sending ? null : _send,
                child: Container(
                  width: 48, height: 48,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF00A884)),
                  child: _sending
                    ? const Padding(
                        padding: EdgeInsets.all(14),
                        child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.send, color: Colors.white, size: 22),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
