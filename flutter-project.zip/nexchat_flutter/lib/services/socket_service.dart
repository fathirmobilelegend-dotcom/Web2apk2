import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as ws_status;
import '../config.dart';
import '../app_state.dart';

class SocketService {
  SocketService._();
  static final SocketService instance = SocketService._();
  WebSocketChannel? _ch;
  StreamSubscription? _sub;
  Timer? _reconnect;
  bool _wanted = false;

  final _chatListCtl = StreamController<List<dynamic>>.broadcast();
  final _messageCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _typingCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _statusCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _profileCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _groupCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _msgDeleteCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _bannedCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _sessionKickCtl = StreamController<void>.broadcast();
  final _callOfferCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _callAnswerCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _callIceCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _callEndCtl = StreamController<Map<String, dynamic>>.broadcast();
  final _callBusyCtl = StreamController<Map<String, dynamic>>.broadcast();
  // ✅ FIX: stream online status
  final _onlineCtl = StreamController<Map<String, dynamic>>.broadcast();

  Stream<List<dynamic>> get chatListStream => _chatListCtl.stream;
  Stream<Map<String, dynamic>> get messageStream => _messageCtl.stream;
  Stream<Map<String, dynamic>> get typingStream => _typingCtl.stream;
  Stream<Map<String, dynamic>> get statusStream => _statusCtl.stream;
  Stream<Map<String, dynamic>> get profileStream => _profileCtl.stream;
  Stream<Map<String, dynamic>> get groupStream => _groupCtl.stream;
  Stream<Map<String, dynamic>> get msgDeleteStream => _msgDeleteCtl.stream;
  Stream<Map<String, dynamic>> get bannedStream => _bannedCtl.stream;
  Stream<void> get sessionKickStream => _sessionKickCtl.stream;
  Stream<Map<String, dynamic>> get callOfferStream => _callOfferCtl.stream;
  Stream<Map<String, dynamic>> get callAnswerStream => _callAnswerCtl.stream;
  Stream<Map<String, dynamic>> get callIceStream => _callIceCtl.stream;
  Stream<Map<String, dynamic>> get callEndStream => _callEndCtl.stream;
  Stream<Map<String, dynamic>> get callBusyStream => _callBusyCtl.stream;
  Stream<Map<String, dynamic>> get onlineStream => _onlineCtl.stream;

  bool get isConnected => _ch != null;

  Future<void> connect() async {
    _wanted = true;
    if (_ch != null) return;
    final user = AppState.instance.loggedUser.value;
    if (user.isEmpty) return;
    try {
      _ch = WebSocketChannel.connect(Uri.parse(AppConfig.wsUrl));
      await _ch!.ready;
      _ch!.sink.add(jsonEncode({'type': 'auth', 'username': user, 'sessionId': AppState.instance.sessionId.value}));
      _sub = _ch!.stream.listen(_onData, onDone: _onDone, onError: (_) => _onDone());
    } catch (_) { _scheduleReconnect(); }
  }

  void _onDone() { _ch = null; _sub?.cancel(); _sub = null; if (_wanted) _scheduleReconnect(); }
  void _scheduleReconnect() {
    _reconnect?.cancel();
    _reconnect = Timer(const Duration(seconds: 3), () { if (_wanted) connect(); });
  }
  void disconnect() {
    _wanted = false; _reconnect?.cancel(); _sub?.cancel();
    try { _ch?.sink.close(ws_status.goingAway); } catch (_) {}
    _ch = null;
  }

  void _emit(String type, Map<String, dynamic> data) {
    switch (type) {
      case 'chatlist': _chatListCtl.add(data['list'] as List? ?? []); return;
      case 'message': _messageCtl.add(data); return;
      case 'typing': _typingCtl.add(data); return;
      case 'status': _statusCtl.add(data); return;
      // ✅ FIX: online/offline event untuk C1/C2
      case 'user_online': case 'user-offline': case 'user_offline':
      case 'online': case 'offline':
        _onlineCtl.add(data); return;
      case 'profile_updated': _profileCtl.add(data); return;
      case 'group_added': case 'group_updated': case 'group_kicked': case 'group_deleted':
        _groupCtl.add(data); return;
      case 'message_deleted': _msgDeleteCtl.add(data); return;
      case 'banned': _bannedCtl.add(data); return;
      case 'unbanned': _bannedCtl.add({'unbanned': true}); return;
      case 'session_kicked': _sessionKickCtl.add(null); return;
      case 'call-offer': _callOfferCtl.add(data); return;
      case 'call-answer': _callAnswerCtl.add(data); return;
      case 'call-ice': _callIceCtl.add(data); return;
      case 'call-hangup': case 'call-reject': _callEndCtl.add(data); return;
      case 'call-busy': case 'call-busy-self': case 'call-unavailable':
        _callBusyCtl.add(data); return;
    }
  }

  void _onData(dynamic raw) {
    Map<String, dynamic> data;
    try { data = jsonDecode(raw as String) as Map<String, dynamic>; } catch (_) { return; }
    final type = (data['type'] ?? '').toString();
    if (type == 'chatlist') {
      final list = data['list'];
      if (list is List) {
        AppState.instance.applyServerChatList(list);
        _chatListCtl.add(list);
      }
      return;
    }
    _emit(type, data);
  }

  void _send(Map<String, dynamic> m) {
    if (_ch == null) return;
    try { _ch!.sink.add(jsonEncode(m)); } catch (_) {}
  }

  void sendRaw(Map<String, dynamic> m) => _send(m);
  void refreshChatList() => _send({'type': 'refresh_chatlist'});

  void viewing(String? partner) => _send({'type': 'viewing', 'partner': partner});
  void typing(String to, {required bool isGroup, required bool isTyping}) =>
    _send({'type': 'typing', 'to': to, 'isGroup': isGroup, 'isTyping': isTyping});

  void sendMessage({
    required String to, required String id,
    String msgType = 'text', String text = '',
    Map<String, dynamic>? file, Map<String, dynamic>? replyTo,
    bool isGroup = false, bool isChannel = false, bool forwarded = false,
  }) => _send({
    'type': 'message', 'from': AppState.instance.loggedUser.value,
    'to': to, 'id': id, 'isGroup': isGroup, 'isChannel': isChannel,
    'msgType': msgType, 'text': text,
    if (file != null) 'file': file, if (replyTo != null) 'replyTo': replyTo,
    if (forwarded) 'forwarded': true,
  });

  void callOffer(String to, String callType, Map<String, dynamic> sdp) =>
    _send({'type': 'call-offer', 'to': to, 'callType': callType, 'sdp': sdp});
  void callAnswer(String to, Map<String, dynamic> sdp) => _send({'type': 'call-answer', 'to': to, 'sdp': sdp});
  void callIce(String to, Map<String, dynamic> c) => _send({'type': 'call-ice', 'to': to, 'candidate': c});
  void callHangup(String to) => _send({'type': 'call-hangup', 'to': to});
  void callReject(String to, {String reason = 'declined'}) =>
    _send({'type': 'call-reject', 'to': to, 'reason': reason});
}
