import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'socket_service.dart';

enum CallState { idle, outgoing, incoming, connecting, active, ended }

class CallService {
  CallService._();
  static final CallService instance = CallService._();
  final ValueNotifier<CallState> state = ValueNotifier(CallState.idle);
  final ValueNotifier<String> peerUser = ValueNotifier('');
  final ValueNotifier<String> peerName = ValueNotifier('');
  final ValueNotifier<String?> peerAvatar = ValueNotifier(null);
  final ValueNotifier<String> callType = ValueNotifier('audio');
  final ValueNotifier<bool> muted = ValueNotifier(false);
  final ValueNotifier<bool> videoOff = ValueNotifier(false);
  final ValueNotifier<Duration> duration = ValueNotifier(Duration.zero);

  RTCPeerConnection? _pc;
  MediaStream? _local;
  MediaStream? _remote;
  Map<String, dynamic>? _pendingOffer;
  final List<RTCIceCandidate> _pendingCandidates = [];
  Timer? _timer;
  Timer? _answerTimeout;

  MediaStream? get localStream => _local;
  MediaStream? get remoteStream => _remote;

  static const _iceServers = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
    ],
  };

  Future<void> startCall({required String to, required String displayName, String? avatarUrl, required bool isVideo}) async {
    if (state.value != CallState.idle) return;
    peerUser.value = to; peerName.value = displayName; peerAvatar.value = avatarUrl;
    callType.value = isVideo ? 'video' : 'audio';
    muted.value = false; videoOff.value = false;
    _pendingCandidates.clear(); state.value = CallState.outgoing;
    await _setupLocal(isVideo: isVideo);
    await _createPeer();
    _local!.getTracks().forEach((t) => _pc!.addTrack(t, _local!));
    final offer = await _pc!.createOffer({'offerToReceiveAudio': true, 'offerToReceiveVideo': isVideo});
    await _pc!.setLocalDescription(offer);
    SocketService.instance.callOffer(to, callType.value, {'type': offer.type, 'sdp': offer.sdp});
    _answerTimeout?.cancel();
    _answerTimeout = Timer(const Duration(seconds: 60), () {
      if (state.value == CallState.outgoing) endCall();
    });
  }

  Future<void> acceptIncoming() async {
    if (state.value != CallState.incoming || _pendingOffer == null) return;
    state.value = CallState.connecting;
    await _setupLocal(isVideo: callType.value == 'video');
    await _createPeer();
    await _pc!.setRemoteDescription(RTCSessionDescription(
      _pendingOffer!['sdp'] as String?, _pendingOffer!['type'] as String?));
    _pendingOffer = null;
    _local!.getTracks().forEach((t) => _pc!.addTrack(t, _local!));
    for (final c in _pendingCandidates) { try { await _pc!.addCandidate(c); } catch (_) {} }
    _pendingCandidates.clear();
    final answer = await _pc!.createAnswer();
    await _pc!.setLocalDescription(answer);
    SocketService.instance.callAnswer(peerUser.value, {'type': answer.type, 'sdp': answer.sdp});
  }

  void rejectIncoming({String reason = 'declined'}) {
    if (peerUser.value.isNotEmpty) SocketService.instance.callReject(peerUser.value, reason: reason);
    _cleanup();
  }

  void endCall() {
    if (peerUser.value.isNotEmpty && state.value != CallState.idle) {
      SocketService.instance.callHangup(peerUser.value);
    }
    _cleanup();
  }

  void handleIncomingOffer(Map<String, dynamic> data) {
    if (state.value != CallState.idle) {
      SocketService.instance.callReject((data['from'] ?? '').toString(), reason: 'busy');
      return;
    }
    peerUser.value = (data['from'] ?? '').toString();
    peerName.value = (data['fromName'] ?? data['from'] ?? '').toString();
    peerAvatar.value = data['fromAvatar'] as String?;
    callType.value = (data['callType'] ?? 'audio').toString();
    _pendingOffer = data['sdp'] as Map<String, dynamic>?;
    _pendingCandidates.clear();
    state.value = CallState.incoming;
  }

  Future<void> handleAnswer(Map<String, dynamic> data) async {
    if (_pc == null) return;
    final sdp = data['sdp'] as Map<String, dynamic>?;
    if (sdp == null) return;
    try {
      await _pc!.setRemoteDescription(RTCSessionDescription(sdp['sdp'] as String?, sdp['type'] as String?));
      if (state.value == CallState.outgoing) {
        state.value = CallState.connecting; _answerTimeout?.cancel();
      }
      for (final c in _pendingCandidates) { try { await _pc!.addCandidate(c); } catch (_) {} }
      _pendingCandidates.clear();
    } catch (e) { debugPrint('handleAnswer: $e'); }
  }

  Future<void> handleIce(Map<String, dynamic> data) async {
    final cand = data['candidate'];
    if (cand == null) return;
    final rtc = RTCIceCandidate(cand['candidate'] as String?, cand['sdpMid'] as String?, cand['sdpMLineIndex'] as int?);
    if (_pc == null || _pc!.getRemoteDescription() == null) { _pendingCandidates.add(rtc); return; }
    try { await _pc!.addCandidate(rtc); } catch (_) {}
  }

  void handleRemoteEnd(Map<String, dynamic> data) { _cleanup(); }

  Future<void> _setupLocal({required bool isVideo}) async {
    _local = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': isVideo ? {'facingMode': 'user', 'width': 1280, 'height': 720} : false,
    });
  }

  Future<void> _createPeer() async {
    _pc = await createPeerConnection(_iceServers);
    _remote = await createLocalMediaStream('remote');
    _pc!.onIceCandidate = (c) {
      if (c.candidate == null) return;
      SocketService.instance.callIce(peerUser.value, {
        'candidate': c.candidate, 'sdpMid': c.sdpMid, 'sdpMLineIndex': c.sdpMLineIndex,
      });
    };
    _pc!.onTrack = (e) { if (e.streams.isNotEmpty) _remote = e.streams[0]; _transitionActive(); };
    _pc!.onIceConnectionState = (s) {
      if (s == RTCIceConnectionState.RTCIceConnectionStateConnected ||
          s == RTCIceConnectionState.RTCIceConnectionStateCompleted) {
        _transitionActive();
      } else if (s == RTCIceConnectionState.RTCIceConnectionStateFailed) {
        endCall();
      }
    };
  }

  void _transitionActive() {
    if (state.value == CallState.active) return;
    state.value = CallState.active;
    _answerTimeout?.cancel(); _timer?.cancel();
    duration.value = Duration.zero;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      duration.value = duration.value + const Duration(seconds: 1);
    });
  }

  Future<void> toggleMute() async {
    if (_local == null) return;
    muted.value = !muted.value;
    for (final t in _local!.getAudioTracks()) t.enabled = !muted.value;
  }

  Future<void> toggleVideo() async {
    if (_local == null) return;
    videoOff.value = !videoOff.value;
    for (final t in _local!.getVideoTracks()) t.enabled = !videoOff.value;
  }

  Future<void> switchCamera() async {
    if (_local == null) return;
    final tracks = _local!.getVideoTracks();
    if (tracks.isEmpty) return;
    await Helper.switchCamera(tracks.first);
  }

  Future<void> _cleanup() async {
    _timer?.cancel(); _timer = null;
    _answerTimeout?.cancel(); _answerTimeout = null;
    try { await _pc?.close(); } catch (_) {}
    _pc = null;
    try { _local?.getTracks().forEach((t) => t.stop()); } catch (_) {}
    try { _remote?.getTracks().forEach((t) => t.stop()); } catch (_) {}
    _local = null; _remote = null; _pendingOffer = null;
    _pendingCandidates.clear();
    state.value = CallState.idle;
    peerUser.value = ''; peerName.value = ''; peerAvatar.value = null;
    muted.value = false; videoOff.value = false; duration.value = Duration.zero;
  }
}
