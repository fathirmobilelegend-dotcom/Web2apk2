import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  final ValueNotifier<String> pendingOpenChat = ValueNotifier('');
  static const String _chatChannelId = 'nexchat_messages';
  static const String _callChannelId = 'nexchat_calls';

  Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false);
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: _onTap,
      onDidReceiveBackgroundNotificationResponse: _onTapBg,
    );
    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidPlugin != null) {
      await androidPlugin.createNotificationChannel(const AndroidNotificationChannel(
        _chatChannelId, 'Chat Messages', description: 'Notifikasi pesan masuk', importance: Importance.high));
      await androidPlugin.createNotificationChannel(const AndroidNotificationChannel(
        _callChannelId, 'Panggilan Masuk', description: 'Notifikasi panggilan',
        importance: Importance.max, playSound: true));
    }
  }

  Future<void> requestPermissions() async {
    try {
      final androidPlugin = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (androidPlugin != null) {
        await androidPlugin.requestNotificationsPermission();
      }
      await [
        Permission.notification,
        Permission.microphone,
        Permission.camera,
        Permission.storage,
        Permission.phone,
      ].request();
    } catch (_) {}
  }

  void _onTap(NotificationResponse r) {
    final payload = r.payload;
    if (payload == null) return;
    try {
      final m = jsonDecode(payload) as Map<String, dynamic>;
      if (m['chatId'] != null) pendingOpenChat.value = m['chatId'].toString();
    } catch (_) {}
  }

  @pragma('vm:entry-point')
  static void _onTapBg(NotificationResponse r) {}

  Future<void> showChatNotification({
    required String chatId, required String from, required String fromDisplay,
    required String body, String? avatarUrl, bool isGroup = false, bool isChannel = false,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      _chatChannelId, 'Chat Messages', channelDescription: 'Notifikasi pesan masuk',
      importance: Importance.high, priority: Priority.high,
      category: AndroidNotificationCategory.message,
      styleInformation: BigTextStyleInformation(body),
      groupKey: isGroup ? 'grp_$chatId' : chatId, autoCancel: true,
      ticker: '$fromDisplay: $body',
    );
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    await _plugin.show(chatId.hashCode & 0x7fffffff,
      fromDisplay.isEmpty ? from : fromDisplay, body,
      NotificationDetails(android: androidDetails, iOS: iosDetails),
      payload: jsonEncode({'chatId': chatId, 'from': from, 'isGroup': isGroup}));
  }

  Future<void> showIncomingCallNotification({
    required String from, required String fromDisplay, required String callType,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      _callChannelId, 'Panggilan Masuk', channelDescription: 'Notifikasi panggilan',
      importance: Importance.max, priority: Priority.max,
      category: AndroidNotificationCategory.call,
      fullScreenIntent: true, ongoing: true, autoCancel: false,
      actions: const [
        AndroidNotificationAction('accept', 'Terima', showsUserInterface: true),
        AndroidNotificationAction('reject', 'Tolak', showsUserInterface: true),
      ],
    );
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    await _plugin.show(9999,
      callType == 'video' ? 'Panggilan video masuk' : 'Panggilan suara masuk',
      '$fromDisplay sedang memanggil Anda',
      NotificationDetails(android: androidDetails, iOS: iosDetails),
      payload: jsonEncode({'incomingCall': true, 'from': from, 'callType': callType}));
  }

  Future<void> cancelCallNotification() async { await _plugin.cancel(9999); }
  Future<void> cancelAll() async { await _plugin.cancelAll(); }
}
