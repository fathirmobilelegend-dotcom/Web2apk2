import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';

class ApiException implements Exception {
  final int status;
  final String message;
  ApiException(this.status, this.message);
  @override
  String toString() => 'ApiException($status): $message';
}

class ApiService {
  static final _client = http.Client();
  static Map<String, String> _headers() => {
    'Content-Type': 'application/json', 'Accept': 'application/json',
  };

  static Future<Map<String, dynamic>> _json(http.Response r) async {
    final body = r.body.isEmpty ? '{}' : r.body;
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) return decoded;
      return {'data': decoded};
    } catch (_) {
      return {'error': 'Invalid JSON', 'raw': body};
    }
  }

  static Future<Map<String, dynamic>> get(String path, {Map<String, String>? q}) async {
    final uri = Uri.parse('${AppConfig.backendUrl}$path').replace(queryParameters: q);
    final r = await _client.get(uri, headers: _headers()).timeout(const Duration(seconds: 15));
    return _json(r);
  }

  static Future<Map<String, dynamic>> post(String path, [Map<String, dynamic>? body]) async {
    final r = await _client.post(Uri.parse('${AppConfig.backendUrl}$path'),
        headers: _headers(), body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 30));
    return _json(r);
  }

  static Future<Map<String, dynamic>> delete(String path) async {
    final r = await _client.delete(Uri.parse('${AppConfig.backendUrl}$path'),
        headers: _headers()).timeout(const Duration(seconds: 20));
    return _json(r);
  }

  static Future<Map<String, dynamic>> register(String u, String p) => post('/api/register', {'username': u, 'password': p});
  static Future<Map<String, dynamic>> login(String u, String p) => post('/api/login', {'username': u, 'password': p});
  static Future<Map<String, dynamic>> me(String u) => get('/api/me/$u');
  static Future<Map<String, dynamic>> changePassword(String u, String np) => post('/api/change-password', {'username': u, 'newPassword': np});
  static Future<Map<String, dynamic>> banInfo(String u) => get('/api/ban/info/$u');
  static Future<Map<String, dynamic>> submitAppeal(String u, String t) => post('/api/ban/appeal', {'username': u, 'text': t});

  static Future<List<dynamic>> chatList(String u) async {
    final r = await get('/api/chats/$u');
    final d = r['data'];
    if (d is List) return d;
    return <dynamic>[];
  }
  static Future<List<dynamic>> chatHistory(String u1, String u2) async {
    final r = await get('/api/chat/$u1/$u2');
    return (r['messages'] as List?) ?? [];
  }
  static Future<List<dynamic>> groupHistory(String g, String u) async {
    final r = await get('/api/groupchat/$g/$u');
    return (r['messages'] as List?) ?? [];
  }
  static Future<Map<String, dynamic>> channelHistory(String u) => get('/api/channel/$u');
  static Future<Map<String, dynamic>> deleteMessage(String u, String cid, String mid, {bool forEveryone = false}) =>
    post('/api/message/delete', {'username': u, 'chatId': cid, 'messageId': mid, 'forEveryone': forEveryone});

  static Future<Map<String, dynamic>> markRead({
    required String username,
    required String partner,
    bool isGroup = false,
    bool isChannel = false,
  }) => post('/api/chat/mark-read', {
    'username': username,
    'partner': partner,
    'isGroup': isGroup,
    'isChannel': isChannel,
  });

  static Future<Map<String, dynamic>> profile(String u, {String? viewer}) =>
    get('/api/profile/$u', q: viewer != null ? {'viewer': viewer} : null);
  static Future<Map<String, dynamic>> updateProfile({
    required String username, String? bio, String? avatar, String? displayName, String? theme,
  }) => post('/api/profile', {
    'username': username,
    if (bio != null) 'bio': bio, if (avatar != null) 'avatar': avatar,
    if (displayName != null) 'displayName': displayName, if (theme != null) 'theme': theme,
  });
  static Future<Map<String, dynamic>> group(String id) => get('/api/group/$id');
  static Future<Map<String, dynamic>> createGroup({
    required String username, required String name, required String groupUsername,
    List<String> members = const [], String description = '', bool isPrivate = false,
  }) => post('/api/group/create', {
    'username': username, 'name': name, 'groupUsername': groupUsername,
    'members': members, 'description': description, 'isPrivate': isPrivate,
  });
  static Future<Map<String, dynamic>> joinPublicGroup(String u, String gu) =>
    post('/api/group/join-public', {'username': u, 'groupUsername': gu});
  static Future<Map<String, dynamic>> joinViaLink(String u, String c) =>
    post('/api/group/join-via-link', {'username': u, 'inviteCode': c});
  static Future<Map<String, dynamic>> leaveGroup(String u, String gid) =>
    post('/api/group/leave', {'username': u, 'groupId': gid});
  static Future<Map<String, dynamic>> block(String u, String t) => post('/api/block', {'username': u, 'target': t});
  static Future<Map<String, dynamic>> unblock(String u, String t) => post('/api/unblock', {'username': u, 'target': t});
  static Future<List<dynamic>> blocks(String u) async {
    final r = await get('/api/blocks/$u');
    return (r['list'] as List?) ?? [];
  }
  static Future<Map<String, dynamic>> search(String q, {String? exclude}) =>
    get('/api/search', q: {'q': q, if (exclude != null) 'exclude': exclude});
  static Future<List<dynamic>> sessions(String u) async {
    final r = await get('/api/sessions/$u');
    return (r['sessions'] as List?) ?? [];
  }
  static Future<Map<String, dynamic>> logoutSession(String u, String sid) => post('/api/session/logout', {'username': u, 'sessionId': sid});
  static Future<Map<String, dynamic>> statusList(String u) => get('/api/status/list/$u');
  static Future<Map<String, dynamic>> myStatuses(String u) => get('/api/status/mine/$u');
  static Future<Map<String, dynamic>> viewStatus(String o, String v) =>
    get('/api/status/view/$o', q: {'viewer': v});
  static Future<Map<String, dynamic>> createStatus({
    required String username, String text = '', String? image, String? video,
  }) => post('/api/status/create', {
    'username': username, 'text': text,
    if (image != null) 'image': image, if (video != null) 'video': video,
  });
  static Future<Map<String, dynamic>> deleteStatus(String u, String id) =>
    post('/api/status/delete', {'username': u, 'statusId': id});
}
