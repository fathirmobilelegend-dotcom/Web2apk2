import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

class AppState {
  AppState._();
  static final AppState instance = AppState._();

  final ValueNotifier<String> loggedUser  = ValueNotifier('');
  final ValueNotifier<String> sessionId   = ValueNotifier('');
  final ValueNotifier<String> displayName = ValueNotifier('');
  final ValueNotifier<String?> avatar     = ValueNotifier(null);
  final ValueNotifier<String> bio         = ValueNotifier('');
  final ValueNotifier<bool>   isDev       = ValueNotifier(false);
  final ValueNotifier<String> theme       = ValueNotifier('dark');
  final ValueNotifier<List<Map<String, dynamic>>> chatList = ValueNotifier([]);
  final ValueNotifier<Map<String, Map<String, dynamic>>> peers = ValueNotifier({});
  final ValueNotifier<String> openChatId = ValueNotifier('');
  // ✅ FIX: track online status peer
  final ValueNotifier<Map<String, bool>> peersOnline = ValueNotifier({});

  final Set<String> _locallyClearedChats = {};
  final Map<String, Map<String, dynamic>> _localLastMsg = {};

  String _chatKey({String? partner, bool isGroup = false, bool isChannel = false}) {
    if (isChannel) return 'channel';
    if (isGroup) return 'grp_$partner';
    return '$partner';
  }

  int _tsOf(dynamic m) {
    if (m is! Map) return 0;
    final ts = m['timestamp'];
    if (ts is int) return ts;
    if (ts is String) {
      try { return DateTime.parse(ts).millisecondsSinceEpoch; } catch (_) {}
      try {
        final parts = ts.split(':');
        if (parts.length >= 2) {
          final h = int.parse(parts[0]);
          final mn = int.parse(parts[1]);
          final now = DateTime.now();
          return DateTime(now.year, now.month, now.day, h, mn).millisecondsSinceEpoch;
        }
      } catch (_) {}
    }
    return 0;
  }

  Future<void> loadSession() async {
    final sp = await SharedPreferences.getInstance();
    theme.value = sp.getString(AppConfig.kTheme) ?? 'dark';
    final raw = sp.getString(AppConfig.kSession);
    if (raw == null) return;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      loggedUser.value  = (m['username']  ?? '').toString();
      sessionId.value   = (m['sessionId'] ?? '').toString();
      displayName.value = (m['displayName'] ?? '').toString();
      avatar.value      = m['avatar'] as String?;
      bio.value         = (m['bio'] ?? '').toString();
      isDev.value       = m['isDev'] == true;
      if (m['theme'] != null && (m['theme'] as String).isNotEmpty) {
        theme.value = m['theme'].toString();
      }
    } catch (_) {}
  }

  Future<void> saveSession({
    required String username, required String sessionIdStr,
    String? display, String? avatarUrl, String? bioText,
    bool? dev, String? themeId,
  }) async {
    loggedUser.value = username;
    sessionId.value  = sessionIdStr;
    if (display != null) displayName.value = display;
    if (avatarUrl != null) avatar.value = avatarUrl;
    if (bioText != null) bio.value = bioText;
    if (dev != null) isDev.value = dev;
    if (themeId != null) theme.value = themeId;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(AppConfig.kSession, jsonEncode({
      'username': username, 'sessionId': sessionIdStr,
      'displayName': displayName.value, 'avatar': avatar.value,
      'bio': bio.value, 'isDev': isDev.value, 'theme': theme.value,
      'ts': DateTime.now().millisecondsSinceEpoch,
    }));
  }

  Future<void> updateProfile({
    String? display, String? avatarUrl, String? bioText, bool clearAvatar = false,
  }) async {
    if (display != null) displayName.value = display;
    if (clearAvatar) avatar.value = null;
    if (avatarUrl != null) avatar.value = avatarUrl;
    if (bioText != null) bio.value = bioText;
    await saveSession(username: loggedUser.value, sessionIdStr: sessionId.value,
      display: displayName.value, avatarUrl: avatar.value, bioText: bio.value,
      dev: isDev.value, themeId: theme.value);
  }

  Future<void> setTheme(String themeId) async {
    theme.value = themeId;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(AppConfig.kTheme, themeId);
  }

  // ✅ FIX: update online status peer (untuk C1/C2)
  void updatePeerOnline(String user, bool isOnline) {
    final m = Map<String, bool>.from(peersOnline.value);
    if (m[user] == isOnline) return;
    m[user] = isOnline;
    peersOnline.value = m;
  }

  bool isPeerOnline(String user) => peersOnline.value[user] == true;

  void markChatRead({
    required String? partner,
    required bool isGroup,
    required bool isChannel,
  }) {
    final key = _chatKey(partner: partner, isGroup: isGroup, isChannel: isChannel);
    _locallyClearedChats.add(key);
    Future.delayed(const Duration(seconds: 20), () {
      _locallyClearedChats.remove(key);
    });
    _applyReadOverride();
  }

  void setLocalLastMsg({
    required String? partner,
    required bool isGroup,
    required bool isChannel,
    required Map<String, dynamic> msg,
  }) {
    final key = _chatKey(partner: partner, isGroup: isGroup, isChannel: isChannel);
    _localLastMsg[key] = msg;
    Future.delayed(const Duration(seconds: 30), () {
      _localLastMsg.remove(key);
    });
    _applyLocalLastMsg();
  }

  void _applyLocalLastMsg() {
    final list = chatList.value;
    if (list.isEmpty) return;
    final newList = list.map((c) {
      final key = _chatKey(
        partner: (c['partner'] ?? '').toString(),
        isGroup: c['isGroup'] == true,
        isChannel: c['isChannel'] == true,
      );
      final override = _localLastMsg[key];
      if (override != null) {
        final serverTs = _tsOf(c['lastMsg']);
        final localTs = _tsOf(override);
        if (localTs >= serverTs) {
          return {...c, 'lastMsg': override};
        }
      }
      return c;
    }).toList();
    newList.sort((a, b) => _tsOf(b['lastMsg']).compareTo(_tsOf(a['lastMsg'])));
    chatList.value = newList;
  }

  void applyServerChatList(List<dynamic> raw) {
    final newList = raw.map((e) {
      final c = Map<String, dynamic>.from(e as Map);
      final key = _chatKey(
        partner: (c['partner'] ?? '').toString(),
        isGroup: c['isGroup'] == true,
        isChannel: c['isChannel'] == true,
      );
      if (_locallyClearedChats.contains(key)) {
        c['unread'] = 0;
      }
      final override = _localLastMsg[key];
      if (override != null) {
        final serverTs = _tsOf(c['lastMsg']);
        final localTs = _tsOf(override);
        if (localTs >= serverTs) {
          c['lastMsg'] = override;
        }
      }
      return c;
    }).toList();
    newList.sort((a, b) => _tsOf(b['lastMsg']).compareTo(_tsOf(a['lastMsg'])));
    chatList.value = newList;
  }

  void _applyReadOverride() {
    final list = chatList.value;
    if (list.isEmpty) return;
    final newList = list.map((c) {
      final key = _chatKey(
        partner: (c['partner'] ?? '').toString(),
        isGroup: c['isGroup'] == true,
        isChannel: c['isChannel'] == true,
      );
      if (_locallyClearedChats.contains(key) && ((c['unread'] ?? 0) as int) != 0) {
        return {...c, 'unread': 0};
      }
      return c;
    }).toList();
    chatList.value = newList;
  }

  Future<void> clear() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(AppConfig.kSession);
    loggedUser.value = ''; sessionId.value = ''; displayName.value = '';
    avatar.value = null; bio.value = ''; isDev.value = false;
    chatList.value = []; peers.value = {};
    _locallyClearedChats.clear();
    _localLastMsg.clear();
    peersOnline.value = {};
  }
}
